// ============================================================
// ActiveApe Blocked Page Logic
// ============================================================

(function () {
    "use strict";

    // Dark Mode Check & Sync
    function updateTheme(isDark) {
        console.log("Blocked Page Theme Update:", isDark);
        if (isDark) {
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
        }
    }

    // 1. Check chrome.storage (Primary)
    if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.local.get(['darkMode'], (result) => {
            if (result.darkMode === true || result.darkMode === 'true') {
                updateTheme(true);
            } else {
                // Fallback to localStorage
                const localVal = localStorage.getItem('darkMode') === 'true';
                if (localVal) updateTheme(true);
            }
        });

        // Listen for storage changes
        chrome.storage.onChanged.addListener((changes, area) => {
            if (area === 'local' && changes.darkMode) {
                updateTheme(changes.darkMode.newValue);
            }
        });
    } else {
        // Fallback for non-extension environment
        const localVal = localStorage.getItem('darkMode') === 'true';
        updateTheme(localVal);
        window.addEventListener('storage', (e) => {
            if (e.key === 'darkMode') {
                updateTheme(e.newValue === 'true');
            }
        });
    }

    // ---- Particle Background ----
    var container = document.getElementById("particles");
    for (var i = 0; i < 30; i++) {
        var p = document.createElement("div");
        p.className = "particle";
        p.style.left = Math.random() * 100 + "%";
        p.style.animationDelay = Math.random() * 8 + "s";
        p.style.animationDuration = 6 + Math.random() * 6 + "s";
        p.style.width = p.style.height = 2 + Math.random() * 4 + "px";
        container.appendChild(p);
    }

    // ---- Resolve challenge page URL ----
    function getChallengeURL() {
        if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.getURL) {
            return chrome.runtime.getURL("challenge/challenge.html");
        }
        // Fallback for file:// testing
        var currentPath = window.location.href;
        var basePath = currentPath.substring(0, currentPath.lastIndexOf("/blocked/"));
        return basePath + "/challenge/challenge.html";
    }

    // ---- Challenge Navigation ----
    // Open challenge in a popup window via background message
    function openChallenge(e) {
        if (e) e.stopPropagation();
        if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
            chrome.runtime.sendMessage({ type: "OPEN_CHALLENGE" });
        } else {
            // Fallback for file:// testing
            window.location.href = getChallengeURL();
        }
    }

    document.getElementById("startChallengeBtn").addEventListener("click", openChallenge);

    // Make entire active card clickable
    document.getElementById("sillyGifCard").addEventListener("click", openChallenge);

})();
