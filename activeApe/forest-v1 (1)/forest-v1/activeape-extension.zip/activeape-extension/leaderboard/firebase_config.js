// =======================================================
// 🌍 MULTIPLAYER SETUP (CONFIGURED)
// =======================================================

const FIREBASE_DB_URL = "https://activeape-leaderboard-default-rtdb.firebaseio.com";

window.firebaseConfig = {
    apiKey: "AIzaSyC7HXxkKEuc3wqbXV4swmVkPmgwqXeS9U0",
    authDomain: "activeape-hack.firebaseapp.com",
    databaseURL: FIREBASE_DB_URL,
    projectId: "activeape-hack",
    storageBucket: "activeape-hack.firebasestorage.app",
    messagingSenderId: "616709543281",
    appId: "1:616709543281:web:fb071fc9cbcddf4d5292d0",
    measurementId: "G-R1NX8HJQ46"
};

// Check if configured
window.isFirebaseConfigured = function () {
    return firebaseConfig.apiKey !== "YOUR_API_KEY_HERE";
};
