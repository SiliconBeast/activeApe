// ============================================================
// ActiveApe — Levels Page Logic
// Navigates to challenge page with selected mode + shows profile
// ============================================================

(function () {
    "use strict";

    // Dark Mode Check & Sync
    function updateTheme() {
        const isDark = localStorage.getItem('darkMode') === 'true';
        if (isDark) {
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
        }
    }

    // Initial check
    updateTheme();

    // Listen for changes from other tabs/popup
    window.addEventListener('storage', (e) => {
        if (e.key === 'darkMode') {
            updateTheme();
        }
    });

    // ---- Particle Background ----
    var container = document.getElementById("particles");
    for (var i = 0; i < 30; i++) {
        var p = document.createElement("div");
        p.className = "particle";
        p.style.left = Math.random() * 100 + "%";
        p.style.animationDelay = Math.random() * 8 + "s";
        p.style.animationDuration = 6 + Math.random() * 6 + "s";
        p.style.width = p.style.height = 2 + Math.random() * 4 + "px";
        container.appendChild(p);
    }

    // ---- Chrome messaging helper ----
    function sendMsg(msg) {
        return new Promise(function (resolve) {
            if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
                chrome.runtime.sendMessage(msg, function (response) {
                    resolve(response);
                });
            } else {
                resolve(null);
            }
        });
    }

    // ---- Resolve challenge page URL ----
    function getChallengeURL(mode) {
        if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.getURL) {
            return chrome.runtime.getURL("challenge/challenge.html?mode=" + mode);
        }
        // Fallback for file:// testing
        var currentPath = window.location.href;
        var basePath = currentPath.substring(0, currentPath.lastIndexOf("/levels/"));
        return basePath + "/challenge/challenge.html?mode=" + mode;
    }

    // ---- Navigate to challenge ----
    function openChallenge(mode) {
        window.location.href = getChallengeURL(mode);
    }

    // ---- Bind cards ----
    document.getElementById("sillyGifCard").addEventListener("click", function (e) {
        if (e.target.closest(".card-btn") || e.target === document.getElementById("sillyGifBtn")) {
            openChallenge("sillygif");
        }
    });

    document.getElementById("sillyGifBtn").addEventListener("click", function (e) {
        e.stopPropagation();
        openChallenge("sillygif");
    });

    document.getElementById("exerciseCard").addEventListener("click", function (e) {
        if (e.target.closest(".card-btn") || e.target === document.getElementById("exerciseBtn")) {
            openChallenge("exercise");
        }
    });

    document.getElementById("exerciseBtn").addEventListener("click", function (e) {
        e.stopPropagation();
        openChallenge("exercise");
    });

    // Make entire active cards clickable
    // Make entire active cards clickable
    document.getElementById("sillyGifCard").addEventListener("click", function () {
        openChallenge("sillygif");
    });

    document.getElementById("exerciseCard").addEventListener("click", function () {
        openChallenge("exercise");
    });

    // ---- Profile + GIF unlock rendering ----
    function renderProfile(profile) {
        if (!profile || !profile.levelInfo) return;
        var li = profile.levelInfo;

        // Profile card
        var badgeEl = document.getElementById("profileBadge");
        var nameEl = document.getElementById("profileName");
        var spEl = document.getElementById("profileSP");
        var fillEl = document.getElementById("profileXpFill");
        var textEl = document.getElementById("profileXpText");
        var countEl = document.getElementById("challengesCount");

        if (badgeEl) badgeEl.textContent = li.badge;
        if (nameEl) nameEl.textContent = li.name;
        if (spEl) spEl.textContent = li.points + " XP";
        if (fillEl) fillEl.style.width = (li.progress * 100) + "%";
        if (textEl) {
            if (li.nextLevel) {
                textEl.textContent = "Level " + li.level + " \u00b7 " + li.xpIntoLevel + " / " + li.xpForNext + " to next";
            } else {
                textEl.textContent = "Level " + li.level + " \u00b7 MAX LEVEL \ud83c\udfc6";
            }
        }
        if (countEl) countEl.textContent = profile.totalChallengesCompleted || 0;

        // GIF unlock cards
        var gifCards = document.querySelectorAll(".gif-card");
        var unlockedList = li.unlockedGifs || []; // Ensure array

        gifCards.forEach(function (card) {
            var gifName = card.getAttribute("data-gif");
            // Check if gifName exists in the unlocked list
            if (unlockedList.indexOf(gifName) !== -1) {
                card.classList.add("unlocked");
            } else {
                card.classList.remove("unlocked");
            }
        });
    }

    // Load profile on page load
    sendMsg({ type: "GET_PROFILE" }).then(function (profile) {
        if (profile) renderProfile(profile);
    });

})();
