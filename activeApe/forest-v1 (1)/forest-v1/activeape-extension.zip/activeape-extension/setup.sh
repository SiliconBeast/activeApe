#!/bin/bash

# activeApe Setup Script
# Downloads required dependencies for the extension

echo "🦍 Setting up activeApe Development Environment..."

# Ensure lib directory exists
if [ ! -d "lib" ]; then
    echo "Creating lib directory..."
    mkdir -p lib
fi

# Download Firebase Compat Libraries
echo "⬇️  Downloading Firebase dependencies..."

FIREBASE_VERSION="9.22.0"
BASE_URL="https://www.gstatic.com/firebasejs/$FIREBASE_VERSION"

echo "   - firebase-app-compat.js"
curl -s -L -o "lib/firebase-app-compat.js" "$BASE_URL/firebase-app-compat.js"

echo "   - firebase-database-compat.js"
curl -s -L -o "lib/firebase-database-compat.js" "$BASE_URL/firebase-database-compat.js"

echo "✅ Dependencies installed!"
echo "🚀 You can now load the extension in Chrome."
