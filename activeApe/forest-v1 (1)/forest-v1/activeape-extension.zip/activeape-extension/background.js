// ============================================================
// ActiveApe — Background Service Worker
// Handles timer tracking, site blocking, state, and Silly Points
// ============================================================

// Firebase Realtime Database URL (must match firebase_config.js)
const FIREBASE_DB_URL = "https://activeape-leaderboard-default-rtdb.firebaseio.com";

const DEFAULT_STATE = {
    blockedSites: [],        // Array of domain strings (e.g. "youtube.com")
    timerLimit: 25,          // Minutes (Standard Pomodoro)
    elapsedSeconds: 0,       // Cumulative seconds on distraction sites
    isSessionActive: false,  // Whether a focus session is running
    isBlocked: false,        // Whether sites are currently blocked
    blockedTabIds: [],       // Tab IDs that have overlays injected
    // ---- Silly Points (XP) ----
    sillyPoints: 0,
    totalChallengesCompleted: 0,
};

// ============================================================
// SILLY POINTS — Levels, Badges, Unlockable GIFs
// ============================================================

const LEVELS = [
    { level: 1, name: "Newbie", xpRequired: 0, badge: "🥚", unlock: null },
    { level: 2, name: "Mover", xpRequired: 50, badge: "🐣", unlock: null },
    { level: 3, name: "Groover", xpRequired: 150, badge: "🐥", unlock: null },
    { level: 4, name: "Dancer", xpRequired: 350, badge: "🕺", unlock: "Silver Tier" },
    { level: 5, name: "Viber", xpRequired: 650, badge: "💃", unlock: "Gold Tier" },
    { level: 6, name: "Silly King", xpRequired: 1100, badge: "🧠", unlock: "Emerald Tier" },
    { level: 7, name: "Skibidi Lord", xpRequired: 1700, badge: "👑", unlock: "Titan Tier" },
    { level: 8, name: "Sigma", xpRequired: 2500, badge: "💀", unlock: "All GIFs" },
];

function getLevelInfo(points) {
    let current = LEVELS[0];
    for (let i = LEVELS.length - 1; i >= 0; i--) {
        if (points >= LEVELS[i].xpRequired) {
            current = LEVELS[i];
            break;
        }
    }
    const nextLevel = LEVELS.find(l => l.level === current.level + 1) || null;
    const xpIntoLevel = points - current.xpRequired;
    const xpForNext = nextLevel ? (nextLevel.xpRequired - current.xpRequired) : 0;
    const progress = nextLevel ? (xpIntoLevel / xpForNext) : 1;

    // Collect all unlocked GIFs up to this level
    const unlockedGifs = [];
    for (const lvl of LEVELS) {
        if (lvl.xpRequired <= points && lvl.unlock && lvl.unlock !== "All GIFs") {
            unlockedGifs.push(lvl.unlock);
        }
    }
    if (current.level >= 8) {
        // Sigma unlocks everything
        for (const lvl of LEVELS) {
            if (lvl.unlock && lvl.unlock !== "All GIFs" && !unlockedGifs.includes(lvl.unlock)) {
                unlockedGifs.push(lvl.unlock);
            }
        }
    }

    return {
        level: current.level,
        name: current.name,
        badge: current.badge,
        points,
        xpIntoLevel,
        xpForNext,
        progress,
        nextLevel,
        unlockedGifs,
        allLevels: LEVELS,
    };
}

function calculateXP(timerMinutes, score) {
    // Min 1 minute to earn XP
    if (timerMinutes < 1) return 0;
    return Math.floor(timerMinutes * 2 * score);
}

// ---- State helpers ----
async function getState() {
    const data = await chrome.storage.local.get("focusState");
    return { ...DEFAULT_STATE, ...(data.focusState || {}) };
}

async function setState(partial) {
    const current = await getState();
    const next = { ...current, ...partial };
    await chrome.storage.local.set({ focusState: next });
    return next;
}

// ---- Domain matching ----
function extractDomain(url) {
    try {
        const u = new URL(url);
        return u.hostname.replace(/^www\./, "");
    } catch {
        return "";
    }
}

function isDistraction(url, blockedSites) {
    const domain = extractDomain(url);
    if (!domain) return false;
    return blockedSites.some(
        (site) => domain === site || domain.endsWith("." + site)
    );
}

// ---- Timer (Alarms based for Service Worker reliability) ----
// Service workers can be killed at any time, so setInterval is not reliable.
// We use chrome.alarms to trigger the tick.

let tickInterval = null;
let challengeWindowId = null;

async function tick() {
    const state = await getState();
    if (!state.isSessionActive || state.isBlocked) return;

    // Check if ANY active tab is a distraction (more robust than lastFocusedWindow)
    try {
        const activeTabs = await chrome.tabs.query({ active: true });
        let distractionFound = false;

        for (const tab of activeTabs) {
            if (tab && tab.url && isDistraction(tab.url, state.blockedSites)) {
                distractionFound = true;
                break; // Found one, that's enough to count time
            }
        }

        if (distractionFound) {
            // In alarm mode, we might want to check the actual time delta?
            // For simplicity, we assume the alarm fires roughly every 1s or we just increment.
            // But alarms in Chrome are often limited to 1 minute min duration unless using specialized techniques or "unpacked" extension relaxation.
            // HOWEVER, for a precise 1-second focus timer, alarms are tricky. 
            // Better approach for "Active" timer: keep the SW alive.

            const newElapsed = state.elapsedSeconds + 1;
            const limitSeconds = state.timerLimit * 60;

            if (newElapsed >= limitSeconds) {
                // TIME'S UP — block everything
                await setState({
                    elapsedSeconds: limitSeconds,
                    isBlocked: true,
                });
                await blockAllDistractionTabs();
            } else {
                await setState({ elapsedSeconds: newElapsed });
            }
        }
    } catch (e) {
        console.error("Tick error:", e);
    }
}

// Keep-Alive Logic:
// To keep the SW alive for second-by-second updates, we use a dedicated "keep-alive" connection logic
// or we accept that it might sleep and use timestamps.
// But for a "focus" app, users expect strict timing.
// We will use the existing interval BUT add a high-frequency alarm to wake it up if it sleeps.

function startTicking() {
    // 1. Set interval for fast updates while alive
    if (tickInterval) clearInterval(tickInterval);
    tickInterval = setInterval(tick, 1000);

    // 2. Create an alarm to wake us up if we sleep
    chrome.alarms.create("tickHelper", { periodInMinutes: 0.1 }); // 6 seconds (if allowed dev) or 1 min
}

function stopTicking() {
    if (tickInterval) {
        clearInterval(tickInterval);
        tickInterval = null;
    }
    chrome.alarms.clear("tickHelper");
}

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "tickHelper") {
        // Just waking up is enough to restart the interval if needed
        if (!tickInterval) {
            startTicking();
        }
        // Also run a tick immediately
        tick();
    }
});



// ---- Overlay Injection (replaces URL redirect) ----
// This is the KEY change: instead of navigating away from the page,
// we inject a full-screen overlay ON TOP of the page.
// The page never navigates, so video position and scroll are preserved.

async function injectBlockOverlay(tabId) {
    try {
        // Fetch Dark Mode Setting
        const store = await chrome.storage.local.get("darkMode");
        const isDark = store.darkMode === true;

        await chrome.scripting.executeScript({
            target: { tabId },
            args: [isDark],
            func: (isDark) => {
                // Don't inject twice
                if (document.getElementById('activeape-block-overlay')) return;

                // ---- Robust video pausing ----
                // Collect ALL video elements: main document + same-origin iframes
                function getAllVideos() {
                    const videos = Array.from(document.querySelectorAll('video'));
                    // Also try same-origin iframes
                    try {
                        document.querySelectorAll('iframe').forEach(iframe => {
                            try {
                                const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
                                if (iframeDoc) {
                                    videos.push(...Array.from(iframeDoc.querySelectorAll('video')));
                                }
                            } catch (e) { /* cross-origin, skip */ }
                        });
                    } catch (e) { }
                    return videos;
                }

                // Pause all videos and mark which ones we paused
                const allVideos = getAllVideos();
                allVideos.forEach(v => {
                    if (!v.paused) {
                        v.dataset.ffWasPaused = 'true';
                        v.pause();
                    }
                });

                // Watchdog: YouTube and some players auto-resume via JS.
                // Re-pause every 500ms while overlay is active.
                const pauseWatchdog = setInterval(() => {
                    if (!document.getElementById('activeape-block-overlay')) {
                        clearInterval(pauseWatchdog);
                        return;
                    }
                    getAllVideos().forEach(v => {
                        if (!v.paused) {
                            v.dataset.ffWasPaused = 'true';
                            v.pause();
                        }
                    });
                }, 500);

                // Store the watchdog ID so we can clear it on removal
                window.__ffPauseWatchdog = pauseWatchdog;

                // Create full-screen overlay
                const overlay = document.createElement('div');
                overlay.id = 'activeape-block-overlay';

                // Theme Colors
                const bgGradient = isDark
                    ? 'linear-gradient(135deg, #121212 0%, #2C2C2C 100%)'
                    : 'linear-gradient(135deg, #F0EAD6 0%, #E2F0CB 100%)';
                const cardBg = isDark ? '#1E1E1E' : '#FFF8E7';
                const textColor = isDark ? '#E0E0E0' : '#333333';
                const subTextColor = isDark ? '#AAAAAA' : '#555555';
                const borderColor = isDark ? '#555555' : '#333333';
                const shadowColor = isDark ? '#000000' : '#333333';
                const patternColor = isDark ? '#97C1A9' : '#97C1A9'; // Keep accent green
                const patternOpacity = isDark ? '0.1' : '0.3';

                overlay.style.cssText = `
                    position: fixed !important;
                    top: 0 !important; left: 0 !important;
                    width: 100vw !important; height: 100vh !important;
                    z-index: 2147483647 !important;
                    background: ${bgGradient} !important;
                    display: flex !important;
                    flex-direction: column !important;
                    align-items: center !important;
                    justify-content: center !important;
                    font-family: 'Patrick Hand', cursive, sans-serif !important;
                    color: ${textColor} !important;
                    cursor: default !important;
                `;

                overlay.innerHTML = `
                    <div style="
                        position:absolute; top:0; left:0; width:100%; height:100%;
                        background-image: radial-gradient(${patternColor} 1px, transparent 1px);
                        background-size: 20px 20px; opacity: ${patternOpacity}; pointer-events: none;
                    "></div>
                    <div style="
                        text-align:center; max-width:500px; padding:40px;
                        background: ${cardBg}; border: 2px solid ${borderColor}; border-radius: 20px;
                        box-shadow: 8px 8px 0px ${shadowColor}; position: relative; z-index: 10;
                    ">
                        <div style="font-size:80px; margin-bottom:16px; filter:drop-shadow(2px 2px 0px ${shadowColor});">🚫</div>
                        <h1 style="
                            font-size:48px; font-weight:700; margin:0 0 16px; color:${textColor};
                            font-family: 'Patrick Hand', cursive;
                        ">
                            Time's Up!
                        </h1>
                        <p style="
                            font-size:20px; color:${subTextColor}; line-height:1.5; margin:0 0 32px;
                            font-family: 'DM Sans', sans-serif;
                        ">
                            You've used all your distraction time. Complete a silly challenge to continue browsing.
                        </p>
                        <button id="ff-challenge-btn" style="
                            background: #97C1A9;
                            color: #ffffff; border: 2px solid ${borderColor}; padding: 16px 40px;
                            border-radius: 255px 15px 225px 15px / 15px 225px 15px 255px;
                            font-size: 20px; font-weight: 700;
                            cursor: pointer; transition: all 0.2s;
                            box-shadow: 4px 4px 0px ${shadowColor};
                            font-family: 'Patrick Hand', cursive;
                        ">
                            ⚡ Start Challenge
                        </button>
                        <p style="font-size:14px; color:${subTextColor}; margin-top:24px; font-family: 'DM Sans', sans-serif; opacity: 0.7;">
                            Your page progress is preserved.
                        </p>
                    </div>
                `;

                // The overlay covers the full viewport, so page beneath can't be clicked.
                document.documentElement.appendChild(overlay);

                // Challenge button opens the challenge in a popup window
                document.getElementById('ff-challenge-btn').addEventListener('click', () => {
                    chrome.runtime.sendMessage({ type: 'OPEN_CHALLENGE' });
                });
            },
        });
        return true;
    } catch (e) {
        // If injection fails (e.g. chrome:// pages), fall back to redirect
        try {
            const blockedUrl = chrome.runtime.getURL("blocked/blocked.html");
            chrome.tabs.update(tabId, { url: blockedUrl });
        } catch (e2) { }
        return false;
    }
}

async function removeBlockOverlay(tabId) {
    try {
        await chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
                // Stop the pause watchdog
                if (window.__ffPauseWatchdog) {
                    clearInterval(window.__ffPauseWatchdog);
                    window.__ffPauseWatchdog = null;
                }

                const overlay = document.getElementById('activeape-block-overlay');
                if (overlay) {
                    overlay.remove();

                    // Resume only videos that WE paused
                    function getAllVideos() {
                        const videos = Array.from(document.querySelectorAll('video'));
                        try {
                            document.querySelectorAll('iframe').forEach(iframe => {
                                try {
                                    const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
                                    if (iframeDoc) {
                                        videos.push(...Array.from(iframeDoc.querySelectorAll('video')));
                                    }
                                } catch (e) { }
                            });
                        } catch (e) { }
                        return videos;
                    }

                    getAllVideos().forEach(v => {
                        if (v.dataset.ffWasPaused === 'true') {
                            delete v.dataset.ffWasPaused;
                            v.play().catch(() => { });
                        }
                    });
                }
            },
        });
    } catch (e) {
        // Tab may have been closed
    }
}

// ---- Blocking ----
async function blockAllDistractionTabs() {
    const tabs = await chrome.tabs.query({});
    const state = await getState();
    const blockedTabIds = [];

    for (const tab of tabs) {
        if (tab.url && isDistraction(tab.url, state.blockedSites)) {
            await injectBlockOverlay(tab.id);
            blockedTabIds.push(tab.id);
        }
    }

    await setState({ blockedTabIds });
}

async function unblockAllTabs() {
    console.log("unblockAllTabs started");
    // Scan ALL open tabs for overlays (don't rely on stored IDs — they can get stale)
    const allTabs = await chrome.tabs.query({});
    console.log(`Found ${allTabs.length} tabs to check`);
    for (const tab of allTabs) {
        try {
            await removeBlockOverlay(tab.id);
        } catch (e) {
            console.warn(`Failed to remove overlay from tab ${tab.id}:`, e);
        }
    }
    await setState({ blockedTabIds: [] });
    console.log("unblockAllTabs finished");
}

// Re-inject overlay after page loads (handles refresh and new navigation)
chrome.webNavigation.onCompleted.addListener(async (details) => {
    if (details.frameId !== 0) return; // Only main frame
    const state = await getState();
    if (!state.isSessionActive || !state.isBlocked) return;

    if (isDistraction(details.url, state.blockedSites)) {
        await injectBlockOverlay(details.tabId);
        // Track the tab
        if (!state.blockedTabIds.includes(details.tabId)) {
            state.blockedTabIds.push(details.tabId);
            await setState({ blockedTabIds: state.blockedTabIds });
        }
    }
});

// Also intercept tab updates (e.g. user types URL into existing tab)
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete') {
        const state = await getState();
        if (!state.isSessionActive || !state.isBlocked) return;

        if (tab.url && isDistraction(tab.url, state.blockedSites)) {
            await injectBlockOverlay(tabId);
            if (!state.blockedTabIds.includes(tabId)) {
                state.blockedTabIds.push(tabId);
                await setState({ blockedTabIds: state.blockedTabIds });
            }
        }
    }
});

// ---- Message handling (from popup and blocked/challenge pages) ----
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    (async () => {
        switch (msg.type) {
            case "GET_STATE": {
                const state = await getState();
                sendResponse(state);
                break;
            }
            case "START_SESSION": {
                await setState({
                    isSessionActive: true,
                    isBlocked: false,
                    elapsedSeconds: 0,
                    timerLimit: msg.timerLimit || 1,
                });
                startTicking();
                sendResponse({ ok: true });
                break;
            }
            case "STOP_SESSION": {
                console.log("Received STOP_SESSION");
                const stopState = await getState();
                // If blocked, refuse to stop — user must complete the challenge
                if (stopState.isBlocked) {
                    console.log("Refusing stop: Session is blocked");
                    sendResponse({ ok: false, blocked: true, error: "Complete the challenge to unblock." });
                    break;
                }

                console.log("Stopping logic sequence...");
                // 1. Kill the timer mechanism immediately
                stopTicking();

                // 2. Flag session as inactive AND reset time immediately to prevent "Paused" look
                await setState({
                    isSessionActive: false,
                    elapsedSeconds: 0,
                    isBlocked: false
                });

                // 3. Remove overlays (can take time, so we did the above first)
                console.log("Unblocking tabs...");
                try {
                    await unblockAllTabs();
                } catch (e) {
                    console.error("Error unblocking tabs:", e);
                }

                // 4. Final clean state reset
                console.log("Resetting full state...");
                await setState({
                    isSessionActive: false,
                    isBlocked: false,
                    elapsedSeconds: 0,
                    blockedTabIds: [],
                });
                console.log("Session stopped successfully");
                sendResponse({ ok: true });
                break;
            }
            case "ADD_SITE": {
                const state = await getState();
                const domain = msg.domain.replace(/^www\./, "").toLowerCase().trim();
                if (domain && !state.blockedSites.includes(domain)) {
                    state.blockedSites.push(domain);
                    await setState({ blockedSites: state.blockedSites });
                }
                sendResponse({ blockedSites: state.blockedSites });
                break;
            }
            case "REMOVE_SITE": {
                const state = await getState();
                state.blockedSites = state.blockedSites.filter(
                    (s) => s !== msg.domain
                );
                await setState({ blockedSites: state.blockedSites });
                sendResponse({ blockedSites: state.blockedSites });
                break;
            }
            case "SET_TIMER": {
                await setState({ timerLimit: msg.timerLimit });
                sendResponse({ ok: true });
                break;
            }
            case "OPEN_CHALLENGE": {
                // Check for existing challenge/levels windows
                const levelsUrl = chrome.runtime.getURL("levels/levels.html");
                const challengeUrl = chrome.runtime.getURL("challenge/challenge.html");

                chrome.tabs.query({}, (tabs) => {
                    const existing = tabs.find(t => t.url.includes("levels/levels.html") || t.url.includes("challenge/challenge.html"));

                    if (existing) {
                        // Already open: Focus the window/tab
                        chrome.tabs.update(existing.id, { active: true });
                        chrome.windows.update(existing.windowId, { focused: true });
                        sendResponse({ ok: true, reused: true });
                    } else {
                        // Not open: Create new
                        chrome.windows.create({
                            url: levelsUrl,
                            type: "popup",
                            width: 1200,
                            height: 800,
                            focused: true
                        }, (win) => {
                            challengeWindowId = win.id;
                            sendResponse({ ok: true });
                        });
                    }
                });
                return true; // Keep channel open
            }
            case "CHALLENGE_PASSED": {
                // User completed challenge — unblock and reset timer
                const preState = await getState();
                const score = msg.score || 0;
                const xpEarned = calculateXP(preState.timerLimit, score);
                const oldPoints = preState.sillyPoints || 0;
                const newPoints = oldPoints + xpEarned;
                const oldLevel = getLevelInfo(oldPoints).level;
                const newLevelInfo = getLevelInfo(newPoints);
                const didLevelUp = newLevelInfo.level > oldLevel;

                await setState({
                    isBlocked: false,
                    elapsedSeconds: 0,
                    sillyPoints: newPoints,
                    totalChallengesCompleted: (preState.totalChallengesCompleted || 0) + 1,
                });

                // Restart ticking immediately (clean session)
                startTicking();

                // Sync updated XP to Firebase
                syncToFirebase(newPoints);

                // Remove overlays from all blocked tabs (Critical Step)
                try {
                    await unblockAllTabs();
                } catch (e) {
                    console.error("Unblock failed during challenge pass:", e);
                }

                // Focus the first distraction-site tab (e.g. YouTube) so the user returns there
                try {
                    const st = await getState();
                    const allTabs = await chrome.tabs.query({});
                    for (const t of allTabs) {
                        if (t.url && isDistraction(t.url, st.blockedSites)) {
                            await chrome.tabs.update(t.id, { active: true });
                            if (t.windowId) {
                                await chrome.windows.update(t.windowId, { focused: true });
                            }
                            break;
                        }
                    }
                } catch (e) {
                    console.warn("Focus tab failed:", e);
                }

                // Close the challenge popup window
                // Wrap in timeout to allow the 'sendResponse' to get back to the window first
                setTimeout(async () => {
                    if (challengeWindowId) {
                        try {
                            await chrome.windows.remove(challengeWindowId);
                        } catch (e) { console.log("Window already closed"); }
                        challengeWindowId = null;
                    } else if (sender.tab) {
                        try {
                            chrome.tabs.remove(sender.tab.id);
                        } catch (e) { }
                    }
                }, 100);

                sendResponse({
                    ok: true,
                    xpEarned,
                    totalPoints: newPoints, // XP
                    levelInfo: newLevelInfo,
                    didLevelUp,
                    didLevelUp: didLevelUp
                });
                break;
            }
            case "GET_PROFILE": {
                const profileState = await getState();
                const levelInfo = getLevelInfo(profileState.sillyPoints || 0);
                sendResponse({
                    sillyPoints: profileState.sillyPoints || 0,
                    totalChallengesCompleted: profileState.totalChallengesCompleted || 0,
                    levelInfo,
                });
                break;
            }
            default:
                sendResponse({ error: "Unknown message type" });
        }
    })();
    return true; // Keep message channel open for async response
});

// ---- Firebase Sync Helpers ----
async function getFirebaseUserId() {
    try {
        const info = await new Promise((resolve, reject) => {
            chrome.identity.getProfileUserInfo({ accountStatus: 'ANY' }, (userInfo) => {
                if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
                else resolve(userInfo);
            });
        });
        if (info && info.email) {
            return info.email.replace(/\./g, '_').replace(/@/g, '_');
        }
    } catch (e) {
        console.warn('Identity lookup failed:', e);
    }
    // Fallback: persistent local ID
    const data = await chrome.storage.local.get('persistentUserId');
    if (data.persistentUserId) return data.persistentUserId;
    const newId = 'guest_' + Math.random().toString(36).substr(2, 9);
    await chrome.storage.local.set({ persistentUserId: newId });
    return newId;
}

async function syncToFirebase(points) {
    try {
        const userId = await getFirebaseUserId();
        let displayName = 'Anonymous Ape';
        try {
            const info = await new Promise((resolve, reject) => {
                chrome.identity.getProfileUserInfo({ accountStatus: 'ANY' }, (ui) => {
                    if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
                    else resolve(ui);
                });
            });
            if (info && info.email) {
                displayName = info.email.split('@')[0];
                displayName = displayName.charAt(0).toUpperCase() + displayName.slice(1);
            }
        } catch (e) { /* keep default */ }

        const levelInfo = getLevelInfo(points);
        const payload = {
            name: displayName,
            email: displayName,
            points: points,
            level: levelInfo.level,
            badge: levelInfo.badge,
            initial: displayName.charAt(0).toUpperCase(),
            lastSeen: Date.now()
        };

        const url = `${FIREBASE_DB_URL}/users/${userId}.json`;
        const resp = await fetch(url, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        if (!resp.ok) console.warn('Firebase sync failed:', resp.status);
        else console.log('Firebase sync OK — XP:', points);
    } catch (e) {
        console.warn('Firebase sync error:', e);
    }
}

// ---- Startup: Resume ticking if session was active ----
chrome.runtime.onStartup.addListener(async () => {
    const state = await getState();
    if (state.isSessionActive && !state.isBlocked) {
        startTicking();
    }
    // Sync current XP to Firebase on startup
    syncToFirebase(state.sillyPoints || 0);
});

// Also handle install/update
chrome.runtime.onInstalled.addListener(async () => {
    const state = await getState();
    if (state.isSessionActive && !state.isBlocked) {
        startTicking();
    }
    // Sync current XP to Firebase on install/update
    syncToFirebase(state.sillyPoints || 0);


});

// Uninstall Cleanup Hook
// In a real app, this URL would trigger a backend endpoint to delete user data.
chrome.runtime.setUninstallURL("https://activeape.com/goodbye?action=delete_data");

// Alarm fallback to keep service worker alive during active session
chrome.alarms.create("keepAlive", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === "keepAlive") {
        const state = await getState();
        if (state.isSessionActive && !state.isBlocked && !tickInterval) {
            startTicking();
        }
    }
});
