# 🦍 ActiveApe — Chrome Extension

An ActiveApe style productivity extension that blocks distraction sites and makes you earn your way back with **silly GIF challenges** using AI pose estimation.

## Features

- ⏱ **Configurable Focus Timer** — 5-minute increments up to 60 minutes
- 🚫 **Site Blocking** — Add distraction sites (YouTube, Instagram, TikTok, etc.)
- 🤪 **Silly GIF Challenge** — Watch silly GIFs and copy the moves on camera to unlock blocked sites
- 🤖 **AI Pose Estimation** — Uses MediaPipe Pose Landmarker (33 keypoints, GPU-accelerated)
- 🧠 **Motion Comparison** — Cosine similarity of joint angles with 65% pass threshold

## Quick Start

1. Clone this repo:
   ```bash
   git clone <your-repo-url>

2. **Check Dependencies**:
   If `lib/firebase-app-compat.js` is missing (e.g. fresh clone), run:
   ```bash
   cd activeape-extension
   ./setup.sh
   ```
   *(This downloads the required Firebase libraries automatically)*

3. Open Chrome → navigate to `chrome://extensions/`

3. Enable **Developer mode** (toggle in top-right)

4. Click **Load unpacked** → select this folder

5. Click the 🌳 icon in your toolbar → add sites → set timer → **Start Focus**

## Testing

Open `test.html` in Chrome (after loading the extension) for a full test suite that checks:
- ✅ chrome.runtime availability
- ✅ Message passing (GET_STATE)
- ✅ Add/remove blocked sites
- ✅ Start/stop sessions
- ✅ Timer ticking
- ✅ Navigation interception

## How It Works

```
User browses YouTube → Timer counts → Time up → Blocked page → Dance challenge → Pass 65%? → Unlock!
```

1. **Background service worker** tracks time on distraction sites
2. When timer expires → all distraction tabs redirect to **blocked page**
3. User clicks "Silly GIF Challenge" → **dance challenge page** opens
4. User performs dance moves → AI compares poses → **pass/fail**
5. On pass → sites unlock, timer resets

## Project Structure

```
activeape-extension/
├── manifest.json          # Chrome Manifest V3
├── background.js          # Timer engine, site blocking, state
├── test.html              # Test harness for development
├── popup/
│   ├── popup.html         # Extension popup UI
│   ├── popup.css          # Dark theme styles
│   └── popup.js           # UI logic, message passing
├── blocked/
│   ├── blocked.html       # "You've Been Caught!" page
│   ├── blocked.css        # Particle animation, cards
│   └── blocked.js         # Navigation logic
├── challenge/
│   ├── challenge.html     # Dance challenge page
│   ├── challenge.css      # Video boxes, overlays
│   └── challenge.js       # MediaPipe pose + comparison
├── lib/                   # MediaPipe (local)
│   ├── vision_bundle.mjs
│   ├── pose_landmarker_lite.task
│   └── wasm/              # WebAssembly runtime
└── icons/                 # 16/48/128px extension icons
```

## Tech Stack

- Chrome Extension Manifest V3
- MediaPipe Pose Landmarker (WASM + GPU)
- Vanilla JS / CSS (no frameworks)
- Chrome Storage API for persistence

## Team

Built as a group project. Clone and load in Chrome to develop and test.
