// ActiveApe Dashboard — Live Extension Integration

// ---- Chrome messaging helper ----
function sendMsg(msg) {
    return new Promise((resolve) => {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
            try {
                chrome.runtime.sendMessage(msg, (response) => {
                    if (chrome.runtime.lastError) {
                        console.warn('sendMsg error:', chrome.runtime.lastError.message);
                        resolve(null);
                        return;
                    }
                    resolve(response || null);
                });
            } catch (e) {
                console.warn('sendMsg exception:', e);
                resolve(null);
            }
        } else {
            resolve(null);
        }
    });
}

// ---- State ----
let currentView = 'dashboard';
let lastState = null;
let pollTimer = null;

// ---- DOM refs ----
const dashboardView = document.getElementById('dashboardView');
const challengeView = document.getElementById('challengeView');
const videoInterface = document.getElementById('videoInterface');
const timerDisplay = document.getElementById('timerDisplay');
const timerInput = document.getElementById('timerInput');
const sillyGifOption = document.getElementById('sillyGifOption');
const startChallengeBtn = document.getElementById('startChallengeBtn');
const countdown = document.getElementById('countdown');
const resultPanel = document.getElementById('resultPanel');
const continueBtn = document.getElementById('continueBtn');
const tryAgainBtn = document.getElementById('tryAgainBtn');
const addSiteBtn = document.getElementById('addSiteBtn');
const newSiteInput = document.getElementById('newSiteInput');
const sitesList = document.getElementById('sitesList');
const ctaButton = document.querySelector('.cta-button');

// ---- Helpers ----
function formatTime(totalSeconds) {
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

// ---- Live status banner (injected at top) ----
function createStatusBanner() {
    const banner = document.createElement('div');
    banner.id = 'liveBanner';
    banner.style.cssText = `
        position: fixed; top: 0; left: 0; right: 0; z-index: 100;
        padding: 10px 24px; text-align: center;
        font-family: 'DM Sans', sans-serif; font-size: 14px; font-weight: 600;
        transition: all 0.3s ease;
        backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px);
    `;
    banner.innerHTML = '<span id="bannerDot" style="display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:8px;vertical-align:middle;"></span><span id="bannerText">Connecting to extension…</span>';
    document.body.prepend(banner);
}
createStatusBanner();

function updateBanner(state) {
    const banner = document.getElementById('liveBanner');
    const dot = document.getElementById('bannerDot');
    const text = document.getElementById('bannerText');
    if (!banner) return;

    if (!state) {
        banner.style.background = 'rgba(248, 81, 73, 0.15)';
        banner.style.borderBottom = '1px solid rgba(248, 81, 73, 0.3)';
        banner.style.color = '#f85149';
        dot.style.background = '#f85149';
        text.textContent = 'Not connected — open this page from the ActiveApe popup';
        return;
    }
    if (state.isBlocked) {
        banner.style.background = 'rgba(248, 81, 73, 0.12)';
        banner.style.borderBottom = '1px solid rgba(248, 81, 73, 0.25)';
        banner.style.color = '#ff7b72';
        dot.style.background = '#f85149';
        dot.style.boxShadow = '0 0 8px rgba(248,81,73,0.6)';
        text.textContent = 'Sites blocked! Complete a challenge to continue browsing.';
    } else if (state.isSessionActive) {
        banner.style.background = 'rgba(63, 185, 80, 0.1)';
        banner.style.borderBottom = '1px solid rgba(63, 185, 80, 0.2)';
        banner.style.color = '#3fb950';
        dot.style.background = '#3fb950';
        dot.style.boxShadow = '0 0 8px rgba(63,185,80,0.5)';
        text.textContent = 'Focus session active — stay focused!';
    } else {
        banner.style.background = 'rgba(139, 148, 158, 0.08)';
        banner.style.borderBottom = '1px solid rgba(48, 54, 61, 0.5)';
        banner.style.color = '#8b949e';
        dot.style.background = '#8b949e';
        dot.style.boxShadow = 'none';
        text.textContent = 'Idle — start a focus session to block distractions';
    }
}

// ---- Render live state to dashboard ----
function updateDashboard(state) {
    if (!state) return;
    lastState = state;

    const { isSessionActive, isBlocked, elapsedSeconds, timerLimit, blockedSites } = state;
    const limitSeconds = timerLimit * 60;
    const remaining = Math.max(0, limitSeconds - elapsedSeconds);

    const leaderboardNavBtn = document.getElementById('leaderboardNavBtn');
    if (leaderboardNavBtn) {
        leaderboardNavBtn.addEventListener('click', () => {
            document.getElementById('leaderboard-section').scrollIntoView({ behavior: 'smooth' });
        });
    }

    // Timer display
    if (isSessionActive) {
        timerDisplay.textContent = formatTime(remaining);
    } else {
        timerDisplay.textContent = formatTime(limitSeconds);
    }

    // Sync timer input value (only when user isn't editing)
    if (document.activeElement !== timerInput) {
        timerInput.value = timerLimit;
    }

    // Lock timer input during active sessions
    timerInput.disabled = isSessionActive;

    // CTA Button
    if (ctaButton) {
        if (isBlocked) {
            ctaButton.innerHTML = '🔒 Complete Challenge <span class="cta-icon">⚡</span>';
            ctaButton.style.background = 'linear-gradient(135deg, #b62b24 0%, #f85149 100%)';
            ctaButton.style.boxShadow = '0 4px 20px rgba(248, 81, 73, 0.3)';
            ctaButton.onclick = async () => {
                const originalText = ctaButton.innerHTML;
                ctaButton.innerHTML = '⏳ Opening...';
                ctaButton.style.opacity = '0.8';

                try {
                    await sendMsg({ type: 'OPEN_CHALLENGE' });
                } catch (e) {
                    console.error("Open challenge failed", e);
                    alert("Failed to open challenge. Please try again.");
                }

                // Reset after short delay
                setTimeout(() => {
                    ctaButton.innerHTML = originalText;
                    ctaButton.style.opacity = '1';
                }, 1000);
            };
        } else if (isSessionActive) {
            ctaButton.innerHTML = 'Stop Session <span class="cta-icon">⏹</span>';
            ctaButton.style.background = 'linear-gradient(135deg, #b62b24 0%, #da3633 100%)';
            ctaButton.style.boxShadow = '0 4px 20px rgba(218, 54, 51, 0.3)';
            ctaButton.onclick = async () => {
                // Re-check state to prevent stopping while blocked (mirrors popup)
                const current = await sendMsg({ type: 'GET_STATE' });
                if (current && current.isBlocked) {
                    alert("Nice try! You can't stop the session while sites are blocked. Complete the challenge to exit! 🦍");
                    return;
                }
                const resp = await sendMsg({ type: 'STOP_SESSION' });
                if (resp && resp.blocked) {
                    alert("Nice try! You can't stop the session while sites are blocked. Complete the challenge to exit! 🦍");
                    return;
                }
                refresh();
            };
        } else {
            ctaButton.innerHTML = 'Start Focusing <span class="cta-icon">▶</span>';
            ctaButton.style.background = '';
            ctaButton.style.boxShadow = '';
            ctaButton.onclick = async () => {
                // Check if sites are blocked
                const current = await sendMsg({ type: 'GET_STATE' });
                if (!current || !current.blockedSites || current.blockedSites.length === 0) {
                    alert("Wait! You haven't added any sites to block yet. 🛑\n\nAdd a site (e.g. youtube.com) above to start focusing!");
                    return;
                }

                // Read current input value at click time (mirrors popup)
                let limit = parseInt(timerInput.value) || 1;
                if (limit < 1) limit = 1;
                if (limit > 90) limit = 90;
                timerInput.value = limit;
                await sendMsg({ type: 'START_SESSION', timerLimit: limit });
                refresh();
            };
        }
    }

    // Blocked sites list
    renderSites(blockedSites || [], isSessionActive);

    // Show/hide challenge view
    if (isBlocked && currentView === 'dashboard') {
        // Show both dashboard + a blocking overlay hint
    }

    // Banner
    updateBanner(state);
}

// ---- Render Profile (ActiveApe) ----
function renderProfile(profile) {
    if (!profile || !profile.levelInfo) return;
    const li = profile.levelInfo;

    const card = document.getElementById("profileCard");
    const badgeEl = document.getElementById("profileBadge");
    const nameEl = document.getElementById("profileName");
    const spEl = document.getElementById("profileSP");
    const fillEl = document.getElementById("profileXpFill");
    const textEl = document.getElementById("profileXpText");
    const countEl = document.getElementById("challengesCount");

    if (card) card.style.display = "flex"; // Show card
    if (badgeEl) badgeEl.textContent = li.badge;
    if (nameEl) nameEl.textContent = li.name;
    if (spEl) spEl.textContent = li.points + " SP";
    if (fillEl) fillEl.style.width = (li.progress * 100) + "%";
    if (textEl) {
        if (li.nextLevel) {
            textEl.textContent = "Level " + li.level + " · " + li.xpIntoLevel + " / " + li.xpForNext + " to next";
        } else {
            textEl.textContent = "Level " + li.level + " · MAX LEVEL 🏆";
        }
    }
    if (countEl) countEl.textContent = profile.totalChallengesCompleted || 0;
}

// ---- Render sites ----
let lastSitesKey = '';
function renderSites(sites, locked) {
    const key = JSON.stringify(sites) + locked;
    if (key === lastSitesKey) return;
    lastSitesKey = key;

    sitesList.innerHTML = '';
    if (sites.length === 0) {
        sitesList.innerHTML = '<div style="text-align:center;padding:24px;color:var(--text-muted);font-size:14px;">No sites blocked yet. Add some above!</div>';
        return;
    }
    sites.forEach(site => {
        const item = document.createElement('div');
        item.className = 'site-item';
        if (locked) {
            item.innerHTML = `
                <span class="site-url">${site}</span>
                <span style="color:var(--text-muted);font-size:12px;">🔒</span>
            `;
        } else {
            item.innerHTML = `
                <span class="site-url">${site}</span>
                <button class="remove-btn" data-site="${site}">Remove</button>
            `;
            item.querySelector('.remove-btn').addEventListener('click', async () => {
                await sendMsg({ type: 'REMOVE_SITE', domain: site });
                refresh();
            });
        }
        sitesList.appendChild(item);
    });
}

// ---- Timer input → sync with extension (mirrors popup behavior) ----
timerInput.addEventListener('keydown', (e) => {
    const allowed = ['Backspace', 'Delete', 'Tab', 'Escape', 'Enter',
        'ArrowLeft', 'ArrowRight', 'Home', 'End'];
    if (allowed.includes(e.key)) return;
    if ((e.ctrlKey || e.metaKey) && ['a', 'c', 'v', 'x'].includes(e.key)) return;
    if (!/^[0-9]$/.test(e.key)) e.preventDefault();
});

timerInput.addEventListener('paste', (e) => {
    const paste = (e.clipboardData || window.clipboardData).getData('text');
    if (!/^\d+$/.test(paste)) e.preventDefault();
});

timerInput.addEventListener('blur', async () => {
    let val = parseInt(timerInput.value) || 1;
    if (val < 1) val = 1;
    if (val > 90) val = 90;
    timerInput.value = val;
    timerDisplay.textContent = formatTime(val * 60);
    await sendMsg({ type: 'SET_TIMER', timerLimit: val });
});

timerInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') timerInput.blur();
});

// ---- Add site ----
addSiteBtn.addEventListener('click', addSite);
newSiteInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') addSite();
});

async function addSite() {
    const val = newSiteInput.value.trim();
    if (!val) return;
    let domain = val;
    try {
        if (val.includes('://')) {
            domain = new URL(val).hostname;
        } else if (val.includes('/')) {
            domain = val.split('/')[0];
        }
    } catch (e) { }
    domain = domain.replace(/^www\./, '').toLowerCase();
    const resp = await sendMsg({ type: 'ADD_SITE', domain });
    if (resp && resp.blockedSites) {
        renderSites(resp.blockedSites, lastState?.isSessionActive || false);
    }
    newSiteInput.value = '';
}

// ---- Challenge option ----
sillyGifOption.addEventListener('click', () => {
    if (typeof chrome !== 'undefined' && chrome.runtime) {
        sendMsg({ type: 'OPEN_CHALLENGE' });
    }
});

// ---- Navigation ----
function showView(view) {
    dashboardView.style.display = 'none';
    challengeView.classList.remove('active');
    videoInterface.classList.remove('active');

    if (view === 'dashboard') {
        dashboardView.style.display = 'block';
    } else if (view === 'challenge') {
        challengeView.classList.add('active');
    } else if (view === 'video') {
        videoInterface.classList.add('active');
    }
    currentView = view;
}

// ---- Polling ----
async function refresh() {
    const state = await sendMsg({ type: 'GET_STATE' });
    if (state) {
        updateDashboard(state);
        // Also fetch profile
        const profile = await sendMsg({ type: 'GET_PROFILE' });
        if (profile) renderProfile(profile);
    } else {
        updateBanner(null);
    }
}

function startPolling() {
    refresh();
    pollTimer = setInterval(refresh, 1000);
}

// ---- Init ----
startPolling();

// Instant Dark Mode Sync
window.addEventListener('storage', (e) => {
    if (e.key === 'darkMode') {
        const isDark = e.newValue === 'true';
        document.body.classList.toggle('dark-mode', isDark);
        if (themeToggle) themeToggle.textContent = isDark ? '☀️' : '🌙';
    }
});

// Dark Mode Logic
const themeToggle = document.getElementById('themeToggle');
const body = document.body;

// Load state
if (localStorage.getItem('darkMode') === 'true') {
    body.classList.add('dark-mode');
    if (themeToggle) themeToggle.textContent = '☀️';
}

// Toggle handler
if (themeToggle) {
    themeToggle.addEventListener('click', () => {
        body.classList.toggle('dark-mode');
        const isDark = body.classList.contains('dark-mode');
        localStorage.setItem('darkMode', isDark);
        themeToggle.textContent = isDark ? '☀️' : '🌙';
    });
}



window.addEventListener('unload', () => {
    if (pollTimer) clearInterval(pollTimer);
});


// ---- Leaderboard Logic (Migrated) ----
const lbStatusEl = document.getElementById('lbStatus');
const lbListEl = document.getElementById('lbList');
const lbUserBanner = document.getElementById('lbUserBanner');

// Leveling System (Same as background.js)
function getLevelInfo(totalPoints) {
    const levels = [
        { level: 1, min: 0, badge: '🥚' },
        { level: 2, min: 100, badge: '👶' },
        { level: 3, min: 300, badge: '🎓' },
        { level: 4, min: 600, badge: '👔' },
        { level: 5, min: 1000, badge: '🦍' },
        { level: 6, min: 1500, badge: '🚀' },
        { level: 7, min: 2200, badge: '🌕' },
        { level: 8, min: 3000, badge: '⭐' },
        { level: 9, min: 4000, badge: '🔥' },
        { level: 10, min: 5500, badge: '👑' }
    ];
    let current = levels[0];
    let next = null;
    for (let i = 0; i < levels.length; i++) {
        if (totalPoints >= levels[i].min) {
            current = levels[i];
            next = levels[i + 1] || null;
        } else {
            break;
        }
    }
    return {
        level: current.level,
        badge: current.badge,
        min: current.min,
        nextMin: next ? next.min : null
    };
}

async function initLeaderboard() {
    // Dependency Check for Developers/New Installs
    if (typeof firebase === 'undefined') {
        console.error("❌ Firebase libraries missing! Run './setup.sh' in the extension directory to download them.");
        if (lbStatusEl) {
            lbStatusEl.innerHTML = '⚠️ <b>Missing Libs</b>';
            lbStatusEl.title = "Run ./setup.sh to download required files";
            lbStatusEl.style.cursor = "help";
            lbStatusEl.style.color = "#f85149";
            lbStatusEl.style.background = "rgba(248, 81, 73, 0.1)";
        }
        if (typeof document !== 'undefined') {
            const list = document.getElementById('lbList');
            if (list) list.innerHTML = '<div style="padding:20px;text-align:center;color:#f85149"><b>Missing Dependencies</b><br><br>Please run <code>./setup.sh</code> in your terminal<br>to download the required libraries.<br><br>(See README.md)</div>';
        }
        return;
    }

    // 1. Get My Info
    let profile = { points: 0, totalChallengesCompleted: 0 };
    try {
        const p = await sendMsg({ type: 'GET_PROFILE' });
        if (p) profile = p;
    } catch (e) {
        console.warn("Failed to fetch profile", e);
    }

    // Get Identity
    let userInfo = { email: 'unknown', id: 'anon' };
    try {
        if (chrome.identity) {
            userInfo = await new Promise(r => {
                chrome.identity.getProfileUserInfo(u => r(u || { email: '', id: '' }));
            });
        }
    } catch (e) { console.warn("Identity fail", e); }

    let displayName = "Anonymous Ape";
    let emailHandle = "@anon";
    let userId = "anon_" + Math.random().toString(36).substr(2, 9);

    if (userInfo.email) {
        emailHandle = userInfo.email.split('@')[0]; // e.g. "john.doe"
        displayName = emailHandle.charAt(0).toUpperCase() + emailHandle.slice(1); // "John.doe"
        userId = userInfo.email.replace(/\./g, '_').replace(/@/g, '_'); // Match background.js logic
    } else {
        // Fallback to local storage ID
        const localId = localStorage.getItem('my_local_user_id');
        if (localId) userId = localId;
        else {
            localStorage.setItem('my_local_user_id', userId);
        }
    }

    // Calc Level
    const myLevel = getLevelInfo(profile.points);

    // Update "My Banner" UI
    if (lbUserBanner) {
        lbUserBanner.style.display = 'flex';
        // Add safeguard for missing elements
        const nameEl = document.getElementById('myName');
        const handleEl = document.getElementById('myHandle');
        const xpEl = document.getElementById('myXP');
        const avatarEl = document.getElementById('myAvatar');

        if (nameEl) nameEl.textContent = displayName + " (You)";
        if (handleEl) handleEl.textContent = "@" + emailHandle;
        if (xpEl) xpEl.textContent = profile.points;
        if (avatarEl) avatarEl.textContent = myLevel.badge;
    }

    // --- FIREBASE SYNC ---
    if (window.isFirebaseConfigured && window.isFirebaseConfigured()) {
        try {
            if (!firebase.apps.length) {
                firebase.initializeApp(firebaseConfig);
            }
            const db = firebase.database();

            // 1. Check for existing user by EMAIL to prevent duplicates
            // "firebase is free from reopeptitons" - User

            const usersRef = db.ref('users');

            // Query by email
            usersRef.orderByChild('email').equalTo(emailHandle).once('value', async (snapshot) => {
                let finalUserId = userId; // Default to the one we generated (chrome.identity or random)
                let existingData = null;

                if (snapshot.exists()) {
                    // Start of the "resume the score" logic
                    const val = snapshot.val();
                    const keys = Object.keys(val);
                    if (keys.length > 0) {
                        finalUserId = keys[0]; // Use the EXISTING key
                        existingData = val[finalUserId];
                        console.log("Found existing user:", finalUserId);
                    }
                }

                // Prepare payload
                const payload = {
                    name: displayName,
                    email: emailHandle,
                    points: Math.max(profile.points || 0, existingData ? existingData.points : 0), // Kept max score just in case
                    level: myLevel.level,
                    badge: myLevel.badge,
                    lastSeen: Date.now()
                };

                // Update (or create if new)
                try {
                    await db.ref('users/' + finalUserId).update(payload);
                    checkConnection(); // Update status UI
                } catch (e) {
                    handleFirebaseError(e);
                }
            });

            // 2. Listen for ALL data
            db.ref('users').on('value', (snapshot) => {
                if (lbStatusEl) {
                    lbStatusEl.innerHTML = '🟢 Live';
                    lbStatusEl.style.color = '#3fb950'; // Green
                    lbStatusEl.style.backgroundColor = 'rgba(63, 185, 80, 0.1)';
                }

                const data = snapshot.val();
                if (!data) return;

                // We need to re-identify "Me" because finalUserId might have changed inside the callback
                // But for the list, we can just match by email if ID match fails, or rely on our session knowledge
                // Ideally we'd update a global 'myFirebaseId' var, but we can match by email for display

                const users = Object.keys(data).map(key => ({
                    ...data[key],
                    id: key,
                    isMe: (data[key].email === emailHandle) // Robust "isMe" check by email
                }));
                users.sort((a, b) => b.points - a.points);
                renderLeaderboardList(users);
            }, (error) => {
                handleFirebaseError(error);
            });

            // 3. Connection Monitor & Fallback
            let isConnected = false;
            const fallbackTimeout = setTimeout(() => {
                if (!isConnected) {
                    console.warn("Firebase WebSocket timed out. Switching to REST polling.");
                    if (lbStatusEl) {
                        lbStatusEl.innerHTML = '⚠️ Polling Mode';
                        lbStatusEl.title = "WebSocket connection failed. Updates might be slower.";
                    }
                    // Kill the SDK listener to prevent conflicts if it wakes up later
                    db.ref('users').off();
                    startRestPolling();
                }
            }, 3500); // 3.5s timeout

            function checkConnection() {
                const connectedRef = db.ref(".info/connected");
                connectedRef.on("value", (snap) => {
                    if (snap.val() === true) {
                        isConnected = true;
                        clearTimeout(fallbackTimeout);
                        if (lbStatusEl) {
                            lbStatusEl.innerHTML = '🟢 Live';
                            lbStatusEl.style.color = '#3fb950';
                            lbStatusEl.style.backgroundColor = 'rgba(63, 185, 80, 0.1)';
                        }
                    } else if (lbStatusEl && !isConnected) {
                        lbStatusEl.innerHTML = '🛰️ Connecting...';
                    }
                });
            }
            checkConnection();

            function handleFirebaseError(e) {
                console.error("Firebase Error:", e);
                // If permission denied or other fatal error, fallback might not help, but worth a try if it's protocol related
                if (!isConnected) {
                    clearTimeout(fallbackTimeout);
                    startRestPolling();
                }
            }

        } catch (e) {
            console.error("Leaderboard Init Error:", e);
            // Immediate fallback if SDK init crashes
            startRestPolling();
        }
    } else {
        if (lbStatusEl) lbStatusEl.innerHTML = '⚠️ API Key Missing';
        startRestPolling();
    }
}

// ---- REST Fallback (Robustness) ----
let pollingInterval = null;
async function startRestPolling() {
    if (pollingInterval) return; // Already running
    console.log("Starting REST polling for leaderboard...");

    // Initial fetch
    await fetchAndRenderRest();

    // Poll every 6 seconds
    pollingInterval = setInterval(fetchAndRenderRest, 6000);
}

async function fetchAndRenderRest() {
    try {
        // Use the global const if available, or try to get it from config
        const url = (typeof FIREBASE_DB_URL !== 'undefined' ? FIREBASE_DB_URL : "https://activeape-leaderboard-default-rtdb.firebaseio.com") + "/users.json";

        const resp = await fetch(url);
        if (!resp.ok) throw new Error("REST fetch failed: " + resp.status);
        const data = await resp.json();

        if (!data) return;

        // "Me" detection (best effort matches logic in initLeaderboard)
        let myEmail = "unknown";
        if (document.getElementById('myHandle')) {
            const h = document.getElementById('myHandle').textContent;
            if (h.startsWith('@')) myEmail = h.substring(1);
        }

        const users = Object.keys(data).map(key => ({
            ...data[key],
            id: key,
            isMe: (data[key].email === myEmail)
        }));
        users.sort((a, b) => b.points - a.points);
        renderLeaderboardList(users);

        if (lbStatusEl) {
            // Only update text if we are definitely in polling mode (prevents overwriting "Connected" if logic races)
            lbStatusEl.innerHTML = '🟢 Live (Polling)';
            lbStatusEl.style.color = '#3fb950';
        }

    } catch (e) {
        console.warn("REST polling error:", e);
        if (lbStatusEl) lbStatusEl.innerHTML = '⚠️ Connection Lost';
    }
}

function renderLeaderboardList(users) {
    if (!lbListEl) return;
    lbListEl.innerHTML = '';

    // Update my rank in banner
    const myIdx = users.findIndex(u => u.isMe);
    if (myIdx !== -1) {
        const rankEl = document.getElementById('myRank');
        if (rankEl) rankEl.textContent = "#" + (myIdx + 1);
    }

    users.forEach((u, index) => {
        const item = document.createElement('div');
        item.className = 'lb-item';
        if (u.isMe) item.classList.add('is-me');

        let rankDisplay = `#${index + 1}`;
        if (index === 0) rankDisplay = '<span class="lb-trophy rank-1">🥇</span>';
        if (index === 1) rankDisplay = '<span class="lb-trophy rank-2">🥈</span>';
        if (index === 2) rankDisplay = '<span class="lb-trophy rank-3">🥉</span>';

        item.innerHTML = `
            <div class="lb-col-rank">${rankDisplay}</div>
            <div class="lb-col-name">
                ${u.name} ${u.isMe ? '(You)' : ''}
                <div style="font-size:11px; opacity:0.6; font-weight:400;">@${u.email ? u.email.split('@')[0] : 'user'}</div>
            </div>
            <div class="lb-col-lvl">${u.level}</div>
            <div class="lb-col-badge">${u.badge}</div>
            <div class="lb-col-xp">${u.points}</div>
        `;
        lbListEl.appendChild(item);
    });
}

// Start Leaderboard
setTimeout(initLeaderboard, 500);


// End of file


