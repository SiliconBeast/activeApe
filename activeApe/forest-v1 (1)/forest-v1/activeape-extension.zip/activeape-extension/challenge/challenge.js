// ============================================================
// ActiveApe — Silly GIF / Exercise Dance Challenge
// MediaPipe Pose Landmarker (LOCAL) + Webcam + Comparison
// ============================================================

(function () {
    "use strict";

    // Dark Mode Check & Sync
    function updateTheme() {
        const isDark = localStorage.getItem('darkMode') === 'true';
        if (isDark) {
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
        }
    }
    updateTheme();

    window.addEventListener('storage', (e) => {
        if (e.key === 'darkMode') {
            updateTheme();
        }
    });

    // ---- Config ----
    const COUNTDOWN_SECONDS = 3;
    const RECORDING_SECONDS = 10;
    const PASS_THRESHOLD = 0.65; // 65% match
    const SAMPLE_RATE_MS = 200;  // Sample pose every 200ms

    // ---- DOM ----
    const $ = function (sel) { return document.querySelector(sel); };
    const countdownOverlay = $("#countdownOverlay");
    const countdownNumber = $("#countdownNumber");
    const resultOverlay = $("#resultOverlay");
    const resultCard = $("#resultCard");
    const resultIcon = $("#resultIcon");
    const resultTitle = $("#resultTitle");
    const resultText = $("#resultText");
    const scoreFill = $("#scoreFill");
    const scoreValue = $("#scoreValue");
    const resultBtn = $("#resultBtn");
    const startBtn = $("#startBtn");
    const controlsHint = $("#controlsHint");
    const referenceCanvas = $("#referenceCanvas");
    const webcamVideo = $("#webcamVideo");
    const webcamCanvas = $("#webcamCanvas");
    const webcamPlaceholder = $("#webcamPlaceholder");
    const recordingBadge = $("#recordingBadge");
    const timerProgress = $("#timerProgress");
    const timerFill = $("#timerFill");

    // ---- State ----
    var poseLandmarker = null;
    var webcamStream = null;
    var isRecording = false;
    var userPoses = [];
    var currentDanceIndex = -1; // will be randomized on first use
    var referenceAnimFrame = null;
    var referenceStartTime = 0;
    var webcamAnimFrame = null;

    // ---- Mode Detection ----
    var urlParams = new URLSearchParams(window.location.search);
    var challengeMode = urlParams.get('mode') || 'exercise'; // Default to exercise

    // ---- Extra DOM refs for mode ----
    var referenceGif = $("#referenceGif");
    var refLabel = $("#refLabel");
    var headerBadge = $(".header-badge");
    var headerTitle = $(".page-header h1");
    var headerDesc = $(".page-header p");

    // ---- Silly GIF-specific dance index (separate from exercise) ----
    var currentSillyGifIndex = -1; // will be randomized on first use

    // ---- Random index picker (avoids repeating the same item back-to-back) ----
    function pickRandomIndex(arrayLength, currentIdx) {
        if (arrayLength <= 1) return 0;
        var next;
        do {
            next = Math.floor(Math.random() * arrayLength);
        } while (next === currentIdx);
        return next;
    }

    // ---- Resolve extension paths (works as extension or file://) ----
    function getExtensionURL(relativePath) {
        if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.getURL) {
            return chrome.runtime.getURL(relativePath);
        }
        // Fallback for standalone file:// testing
        var currentPath = window.location.href;
        var basePath = currentPath.substring(0, currentPath.lastIndexOf("/challenge/"));
        return basePath + "/" + relativePath;
    }

    // ============================================================
    // DANCE SEQUENCES (Synthetic Pose Data)
    // ============================================================

    function generateBasePose() {
        return [
            { x: 0.5, y: 0.15, z: 0, visibility: 1 },  // 0:  nose
            { x: 0.48, y: 0.13, z: 0, visibility: 1 },  // 1:  left_eye_inner
            { x: 0.47, y: 0.13, z: 0, visibility: 1 },  // 2:  left_eye
            { x: 0.46, y: 0.13, z: 0, visibility: 1 },  // 3:  left_eye_outer
            { x: 0.52, y: 0.13, z: 0, visibility: 1 },  // 4:  right_eye_inner
            { x: 0.53, y: 0.13, z: 0, visibility: 1 },  // 5:  right_eye
            { x: 0.54, y: 0.13, z: 0, visibility: 1 },  // 6:  right_eye_outer
            { x: 0.45, y: 0.15, z: 0, visibility: 1 },  // 7:  left_ear
            { x: 0.55, y: 0.15, z: 0, visibility: 1 },  // 8:  right_ear
            { x: 0.48, y: 0.18, z: 0, visibility: 1 },  // 9:  mouth_left
            { x: 0.52, y: 0.18, z: 0, visibility: 1 },  // 10: mouth_right
            { x: 0.38, y: 0.30, z: 0, visibility: 1 },  // 11: left_shoulder
            { x: 0.62, y: 0.30, z: 0, visibility: 1 },  // 12: right_shoulder
            { x: 0.32, y: 0.45, z: 0, visibility: 1 },  // 13: left_elbow
            { x: 0.68, y: 0.45, z: 0, visibility: 1 },  // 14: right_elbow
            { x: 0.30, y: 0.58, z: 0, visibility: 1 },  // 15: left_wrist
            { x: 0.70, y: 0.58, z: 0, visibility: 1 },  // 16: right_wrist
            { x: 0.28, y: 0.60, z: 0, visibility: 1 },  // 17: left_pinky
            { x: 0.72, y: 0.60, z: 0, visibility: 1 },  // 18: right_pinky
            { x: 0.29, y: 0.59, z: 0, visibility: 1 },  // 19: left_index
            { x: 0.71, y: 0.59, z: 0, visibility: 1 },  // 20: right_index
            { x: 0.30, y: 0.59, z: 0, visibility: 1 },  // 21: left_thumb
            { x: 0.70, y: 0.59, z: 0, visibility: 1 },  // 22: right_thumb
            { x: 0.42, y: 0.55, z: 0, visibility: 1 },  // 23: left_hip
            { x: 0.58, y: 0.55, z: 0, visibility: 1 },  // 24: right_hip
            { x: 0.42, y: 0.72, z: 0, visibility: 1 },  // 25: left_knee
            { x: 0.58, y: 0.72, z: 0, visibility: 1 },  // 26: right_knee
            { x: 0.42, y: 0.90, z: 0, visibility: 1 },  // 27: left_ankle
            { x: 0.58, y: 0.90, z: 0, visibility: 1 },  // 28: right_ankle
            { x: 0.41, y: 0.92, z: 0, visibility: 1 },  // 29: left_heel
            { x: 0.59, y: 0.92, z: 0, visibility: 1 },  // 30: right_heel
            { x: 0.42, y: 0.93, z: 0, visibility: 1 },  // 31: left_foot_index
            { x: 0.58, y: 0.93, z: 0, visibility: 1 },  // 32: right_foot_index
        ];
    }

    function clonePose(pose) {
        return pose.map(function (p) { return { x: p.x, y: p.y, z: p.z, visibility: p.visibility }; });
    }

    function generateArmWaveDance() {
        var frames = [];
        var totalFrames = RECORDING_SECONDS * (1000 / SAMPLE_RATE_MS);
        for (var i = 0; i < totalFrames; i++) {
            var t = i / totalFrames;
            var pose = clonePose(generateBasePose());
            var phase = Math.sin(t * Math.PI * 4);
            // Left arm waves up and down
            pose[13].y = 0.30 + phase * -0.15;
            pose[13].x = 0.32 + phase * -0.05;
            pose[15].y = 0.20 + phase * -0.20;
            pose[15].x = 0.25 + phase * -0.08;
            // Right arm mirrors
            pose[14].y = 0.30 - phase * -0.15;
            pose[14].x = 0.68 - phase * 0.05;
            pose[16].y = 0.20 - phase * -0.20;
            pose[16].x = 0.75 - phase * 0.08;
            frames.push(pose);
        }
        return frames;
    }

    function generateShimmyDance() {
        var frames = [];
        var totalFrames = RECORDING_SECONDS * (1000 / SAMPLE_RATE_MS);
        for (var i = 0; i < totalFrames; i++) {
            var t = i / totalFrames;
            var pose = clonePose(generateBasePose());
            var phase = Math.sin(t * Math.PI * 6);
            var shift = phase * 0.04;
            // Shoulders shimmy side to side
            pose[11].x += shift;
            pose[12].x += shift;
            // Arms follow shoulders with raised elbows
            pose[13].y = 0.28; pose[13].x = 0.28 + shift;
            pose[14].y = 0.28; pose[14].x = 0.72 + shift;
            pose[15].y = 0.18; pose[15].x = 0.30 + shift * 1.5;
            pose[16].y = 0.18; pose[16].x = 0.70 + shift * 1.5;
            frames.push(pose);
        }
        return frames;
    }

    function generateDiscoPointDance() {
        var frames = [];
        var totalFrames = RECORDING_SECONDS * (1000 / SAMPLE_RATE_MS);
        for (var i = 0; i < totalFrames; i++) {
            var t = i / totalFrames;
            var pose = clonePose(generateBasePose());
            var cycle = Math.floor(t * 4) % 2;
            var extend = Math.min(1, (t * 4 % 1) * 2);
            if (cycle === 0) {
                // Right arm points up
                pose[14].y = 0.30 - extend * 0.20;
                pose[14].x = 0.68 + extend * 0.05;
                pose[16].y = 0.10 - extend * 0.05;
                pose[16].x = 0.75 + extend * 0.08;
                // Left arm stays down
                pose[13].y = 0.40; pose[15].y = 0.50; pose[15].x = 0.40;
            } else {
                // Left arm points up
                pose[13].y = 0.30 - extend * 0.20;
                pose[13].x = 0.32 - extend * 0.05;
                pose[15].y = 0.10 - extend * 0.05;
                pose[15].x = 0.25 - extend * 0.08;
                // Right arm stays down
                pose[14].y = 0.40; pose[16].y = 0.50; pose[16].x = 0.60;
            }
            // NO leg movement — users are seated
            frames.push(pose);
        }
        return frames;
    }

    function generateClapOverheadDance() {
        var frames = [];
        var totalFrames = RECORDING_SECONDS * (1000 / SAMPLE_RATE_MS);
        for (var i = 0; i < totalFrames; i++) {
            var t = i / totalFrames;
            var pose = clonePose(generateBasePose());
            // Arms raise up and clap overhead, then lower
            var phase = (Math.sin(t * Math.PI * 3) + 1) / 2; // 0→1→0
            // Both arms go from resting to overhead
            pose[13].y = 0.45 - phase * 0.35; // left elbow
            pose[13].x = 0.35 - phase * 0.05;
            pose[14].y = 0.45 - phase * 0.35; // right elbow
            pose[14].x = 0.65 + phase * 0.05;
            pose[15].y = 0.55 - phase * 0.50; // left wrist to top
            pose[15].x = 0.30 + phase * 0.15; // wrists meet at center
            pose[16].y = 0.55 - phase * 0.50; // right wrist to top
            pose[16].x = 0.70 - phase * 0.15;
            frames.push(pose);
        }
        return frames;
    }

    function generateBoxingJabDance() {
        var frames = [];
        var totalFrames = RECORDING_SECONDS * (1000 / SAMPLE_RATE_MS);
        for (var i = 0; i < totalFrames; i++) {
            var t = i / totalFrames;
            var pose = clonePose(generateBasePose());
            var cycle = Math.floor(t * 6) % 2; // alternating jabs
            var punch = Math.min(1, (t * 6 % 1) * 3); // quick extension
            if (cycle === 0) {
                // Left jab forward
                pose[13].y = 0.32; pose[13].x = 0.35;
                pose[15].y = 0.30; pose[15].x = 0.35 - punch * 0.10;
                // Right arm guard
                pose[14].y = 0.35; pose[14].x = 0.60;
                pose[16].y = 0.30; pose[16].x = 0.58;
            } else {
                // Right jab forward
                pose[14].y = 0.32; pose[14].x = 0.65;
                pose[16].y = 0.30; pose[16].x = 0.65 + punch * 0.10;
                // Left arm guard
                pose[13].y = 0.35; pose[13].x = 0.40;
                pose[15].y = 0.30; pose[15].x = 0.42;
            }
            frames.push(pose);
        }
        return frames;
    }

    function generateChickenWingsDance() {
        var frames = [];
        var totalFrames = RECORDING_SECONDS * (1000 / SAMPLE_RATE_MS);
        for (var i = 0; i < totalFrames; i++) {
            var t = i / totalFrames;
            var pose = clonePose(generateBasePose());
            var flap = Math.sin(t * Math.PI * 8); // fast flapping
            // Elbows go out and up like wings
            pose[13].y = 0.32 + flap * -0.08;
            pose[13].x = 0.28 + flap * -0.06;
            pose[14].y = 0.32 + flap * -0.08;
            pose[14].x = 0.72 + flap * 0.06;
            // Wrists stay near chest (hands on hips-ish)
            pose[15].y = 0.38; pose[15].x = 0.38;
            pose[16].y = 0.38; pose[16].x = 0.62;
            frames.push(pose);
        }
        return frames;
    }

    function generateReachStretchDance() {
        var frames = [];
        var totalFrames = RECORDING_SECONDS * (1000 / SAMPLE_RATE_MS);
        for (var i = 0; i < totalFrames; i++) {
            var t = i / totalFrames;
            var pose = clonePose(generateBasePose());
            var cycle = Math.floor(t * 4) % 2;
            var reach = (Math.sin(t * Math.PI * 4 % Math.PI) + 1) / 2;
            if (cycle === 0) {
                // Left arm reaches up high
                pose[13].y = 0.25 - reach * 0.15;
                pose[13].x = 0.35;
                pose[15].y = 0.10 - reach * 0.08;
                pose[15].x = 0.38;
                // Right arm relaxed
                pose[14].y = 0.42; pose[16].y = 0.55;
            } else {
                // Right arm reaches up high
                pose[14].y = 0.25 - reach * 0.15;
                pose[14].x = 0.65;
                pose[16].y = 0.10 - reach * 0.08;
                pose[16].x = 0.62;
                // Left arm relaxed
                pose[13].y = 0.42; pose[15].y = 0.55;
            }
            frames.push(pose);
        }
        return frames;
    }

    function generateWindmillDance() {
        var frames = [];
        var totalFrames = RECORDING_SECONDS * (1000 / SAMPLE_RATE_MS);
        for (var i = 0; i < totalFrames; i++) {
            var t = i / totalFrames;
            var pose = clonePose(generateBasePose());
            var angle = t * Math.PI * 4; // 2 full rotations
            var radius = 0.18;
            // Left arm circles counterclockwise
            pose[13].x = 0.35 + Math.cos(angle) * radius * 0.5;
            pose[13].y = 0.35 + Math.sin(angle) * radius * 0.5;
            pose[15].x = 0.35 + Math.cos(angle) * radius;
            pose[15].y = 0.35 + Math.sin(angle) * radius;
            // Right arm circles clockwise (opposite phase)
            pose[14].x = 0.65 + Math.cos(angle + Math.PI) * radius * 0.5;
            pose[14].y = 0.35 + Math.sin(angle + Math.PI) * radius * 0.5;
            pose[16].x = 0.65 + Math.cos(angle + Math.PI) * radius;
            pose[16].y = 0.35 + Math.sin(angle + Math.PI) * radius;
            frames.push(pose);
        }
        return frames;
    }

    var DANCE_SEQUENCES = [
        { name: "Arm Wave", description: "Wave your arms up and down!", frames: generateArmWaveDance() },
        { name: "Shoulder Shimmy", description: "Shimmy your shoulders side to side!", frames: generateShimmyDance() },
        { name: "Disco Point", description: "Point up and across — seated disco!", frames: generateDiscoPointDance() },
        { name: "Clap Overhead", description: "Clap your hands above your head!", frames: generateClapOverheadDance() },
        { name: "Boxing Jab", description: "Throw alternating left-right jabs!", frames: generateBoxingJabDance() },
        { name: "Chicken Wings", description: "Flap your elbows like wings!", frames: generateChickenWingsDance() },
        { name: "Reach & Stretch", description: "Reach up high, one arm at a time!", frames: generateReachStretchDance() },
        { name: "Windmill Arms", description: "Circle your arms like a windmill!", frames: generateWindmillDance() }
    ];

    // ============================================================
    // SILLY GIF SEQUENCES (with GIF URLs for display)
    // Each entry has pre-computed pose keypoint frames + a gifUrl
    // User sees the GIF; comparison uses the keypoint frames
    // ============================================================

    function generateTikTokSwayDance() {
        var frames = [];
        var totalFrames = RECORDING_SECONDS * (1000 / SAMPLE_RATE_MS);
        for (var i = 0; i < totalFrames; i++) {
            var t = i / totalFrames;
            var pose = clonePose(generateBasePose());
            // Whole upper body sways side to side with arms flowing
            var sway = Math.sin(t * Math.PI * 5) * 0.06;
            var armFlow = Math.sin(t * Math.PI * 5 + 0.5) * 0.12;
            // Head/shoulders sway
            pose[0].x += sway;
            pose[11].x += sway; pose[12].x += sway;
            // Left arm flows up and out
            pose[13].y = 0.30 + armFlow * -0.08;
            pose[13].x = 0.30 + sway + armFlow * -0.05;
            pose[15].y = 0.22 + armFlow * -0.12;
            pose[15].x = 0.25 + sway + armFlow * -0.08;
            // Right arm mirrors with delay
            var armFlow2 = Math.sin(t * Math.PI * 5 - 0.5) * 0.12;
            pose[14].y = 0.30 + armFlow2 * -0.08;
            pose[14].x = 0.70 + sway + armFlow2 * 0.05;
            pose[16].y = 0.22 + armFlow2 * -0.12;
            pose[16].x = 0.75 + sway + armFlow2 * 0.08;
            frames.push(pose);
        }
        return frames;
    }

    function generateChestPopDance() {
        var frames = [];
        var totalFrames = RECORDING_SECONDS * (1000 / SAMPLE_RATE_MS);
        for (var i = 0; i < totalFrames; i++) {
            var t = i / totalFrames;
            var pose = clonePose(generateBasePose());
            // Sharp chest pop motion — shoulders and elbows snap forward then back
            var pop = Math.pow(Math.abs(Math.sin(t * Math.PI * 6)), 3);
            // Shoulders push forward (y decreases slightly, z doesn't matter visually)
            pose[11].y = 0.30 - pop * 0.03;
            pose[12].y = 0.30 - pop * 0.03;
            // Arms bent at elbows, hands near chest
            pose[13].y = 0.35 - pop * 0.05; pose[13].x = 0.32;
            pose[14].y = 0.35 - pop * 0.05; pose[14].x = 0.68;
            pose[15].y = 0.32; pose[15].x = 0.38 - pop * 0.04;
            pose[16].y = 0.32; pose[16].x = 0.62 + pop * 0.04;
            // Head bobs with pop
            pose[0].y = 0.15 - pop * 0.02;
            frames.push(pose);
        }
        return frames;
    }

    function generateVogueArmsDance() {
        var frames = [];
        var totalFrames = RECORDING_SECONDS * (1000 / SAMPLE_RATE_MS);
        for (var i = 0; i < totalFrames; i++) {
            var t = i / totalFrames;
            var pose = clonePose(generateBasePose());
            // Vogue-style angular arm poses that transition between positions
            var segment = Math.floor(t * 8) % 4;
            var blend = (t * 8) % 1;
            var ease = blend * blend * (3 - 2 * blend); // smoothstep
            if (segment === 0) {
                // Right arm straight up, left arm out
                pose[14].y = 0.30 - ease * 0.25; pose[14].x = 0.65;
                pose[16].y = 0.10 - ease * 0.05; pose[16].x = 0.65;
                pose[13].y = 0.30; pose[13].x = 0.32 - ease * 0.10;
                pose[15].y = 0.30; pose[15].x = 0.20;
            } else if (segment === 1) {
                // Both arms framing face
                pose[13].y = 0.15; pose[13].x = 0.38 - ease * 0.03;
                pose[14].y = 0.15; pose[14].x = 0.62 + ease * 0.03;
                pose[15].y = 0.12; pose[15].x = 0.42;
                pose[16].y = 0.12; pose[16].x = 0.58;
            } else if (segment === 2) {
                // Left arm up, right arm diagonal down
                pose[13].y = 0.30 - ease * 0.25; pose[13].x = 0.35;
                pose[15].y = 0.10 - ease * 0.05; pose[15].x = 0.35;
                pose[14].y = 0.35 + ease * 0.05; pose[14].x = 0.72;
                pose[16].y = 0.45; pose[16].x = 0.80;
            } else {
                // Both arms out wide
                pose[13].y = 0.28; pose[13].x = 0.25 - ease * 0.05;
                pose[14].y = 0.28; pose[14].x = 0.75 + ease * 0.05;
                pose[15].y = 0.25; pose[15].x = 0.15;
                pose[16].y = 0.25; pose[16].x = 0.85;
            }
            frames.push(pose);
        }
        return frames;
    }

    function generateRobotDance() {
        var frames = [];
        var totalFrames = RECORDING_SECONDS * (1000 / SAMPLE_RATE_MS);
        for (var i = 0; i < totalFrames; i++) {
            var t = i / totalFrames;
            var pose = clonePose(generateBasePose());
            // Robotic jerky movements — arms snap to positions
            var step = Math.floor(t * 12) % 6;
            var snap = Math.min(1, ((t * 12) % 1) * 5); // Fast snap
            if (step === 0) { // Right arm out 90°
                pose[14].y = 0.30; pose[14].x = 0.68 + snap * 0.08;
                pose[16].y = 0.30; pose[16].x = 0.82;
                pose[13].y = 0.40; pose[15].y = 0.50;
            } else if (step === 1) { // Right arm up 90°
                pose[14].y = 0.30 - snap * 0.15; pose[14].x = 0.68;
                pose[16].y = 0.15; pose[16].x = 0.68;
                pose[13].y = 0.40; pose[15].y = 0.50;
            } else if (step === 2) { // Left arm out 90°
                pose[13].y = 0.30; pose[13].x = 0.32 - snap * 0.08;
                pose[15].y = 0.30; pose[15].x = 0.18;
                pose[14].y = 0.15; pose[16].y = 0.15;
            } else if (step === 3) { // Left arm up
                pose[13].y = 0.30 - snap * 0.15; pose[13].x = 0.32;
                pose[15].y = 0.15; pose[15].x = 0.32;
                pose[14].y = 0.30; pose[16].y = 0.30;
            } else if (step === 4) { // Both arms out
                pose[13].x = 0.25; pose[14].x = 0.75;
                pose[15].x = 0.15; pose[16].x = 0.85;
                pose[13].y = pose[14].y = 0.28;
                pose[15].y = pose[16].y = 0.28;
            } else { // Both arms crossed
                pose[13].y = 0.32; pose[13].x = 0.55;
                pose[14].y = 0.32; pose[14].x = 0.45;
                pose[15].y = 0.35; pose[15].x = 0.60;
                pose[16].y = 0.35; pose[16].x = 0.40;
            }
            frames.push(pose);
        }
        return frames;
    }

    function generateHypeDance() {
        var frames = [];
        var totalFrames = RECORDING_SECONDS * (1000 / SAMPLE_RATE_MS);
        for (var i = 0; i < totalFrames; i++) {
            var t = i / totalFrames;
            var pose = clonePose(generateBasePose());
            // Energetic hype dance — pumping fists and bouncing
            var bounce = Math.abs(Math.sin(t * Math.PI * 7)) * 0.03;
            var pump = Math.sin(t * Math.PI * 7);
            // Whole body bounces
            for (var j = 0; j < pose.length; j++) {
                pose[j].y -= bounce;
            }
            // Arms pump alternately
            if (pump > 0) {
                // Right fist pump up
                pose[14].y = 0.25 - pump * 0.15; pose[14].x = 0.65;
                pose[16].y = 0.12 - pump * 0.10; pose[16].x = 0.63;
                // Left arm down
                pose[13].y = 0.38; pose[13].x = 0.35;
                pose[15].y = 0.45; pose[15].x = 0.38;
            } else {
                // Left fist pump up
                pose[13].y = 0.25 + pump * 0.15; pose[13].x = 0.35;
                pose[15].y = 0.12 + pump * 0.10; pose[15].x = 0.37;
                // Right arm down
                pose[14].y = 0.38; pose[14].x = 0.65;
                pose[16].y = 0.45; pose[16].x = 0.62;
            }
            frames.push(pose);
        }
        return frames;
    }

    var SILLYGIF_SEQUENCES = [
        { name: "Happy Cat Bop", description: "Bop along with the happy cat!", frames: generateChestPopDance(), gifUrl: chrome.runtime.getURL("gifs/happy_cat_bop.gif") },
        { name: "Funky Arms", description: "Strike funky poses with your arms!", frames: generateVogueArmsDance(), gifUrl: chrome.runtime.getURL("gifs/funky_arms.gif") },
        { name: "Robot Mode", description: "Move like a silly robot!", frames: generateRobotDance(), gifUrl: chrome.runtime.getURL("gifs/robot_mode.gif") },
        { name: "Victory V", description: "Flash the victory sign!", frames: generateVogueArmsDance(), gifUrl: chrome.runtime.getURL("gifs/victory_v.gif") }, // Replaced Party Time

        // Desk Friendly Batch
        { name: "Unicorn Dab", description: "Hit that dab!", frames: generateVogueArmsDance(), gifUrl: chrome.runtime.getURL("gifs/dabbing_unicorn.gif") },

        { name: "Jellyfish Jam", description: "Jam out like Spongebob!", frames: generateHypeDance(), gifUrl: chrome.runtime.getURL("gifs/spongebob_jam.gif") },
        { name: "Hotline Bling", description: "Call me on my cell phone!", frames: generateVogueArmsDance(), gifUrl: chrome.runtime.getURL("gifs/hotline_bling.gif") },
        { name: "Kermit Flail", description: "Yaaaaaaaay!", frames: generateHypeDance(), gifUrl: chrome.runtime.getURL("gifs/kermit_flail.gif") },
        { name: "Peanut Butter", description: "It's Peanut Butter Jelly Time!", frames: generateChestPopDance(), gifUrl: chrome.runtime.getURL("gifs/banana_man.gif") },
        { name: "Double Wave", description: "Wave with both hands!", frames: generateHypeDance(), gifUrl: chrome.runtime.getURL("gifs/double_wave.gif") }, // Replaced Chicken Dance
        { name: "Finger Guns", description: "Pew pew! You got this!", frames: generateVogueArmsDance(), gifUrl: chrome.runtime.getURL("gifs/finger_guns.gif") }, // Replaced Hamster Dance
        { name: "Teletubby Hug", description: "Big hug!", frames: generateTikTokSwayDance(), gifUrl: chrome.runtime.getURL("gifs/teletubbies.gif") },


        // New Upper-Body Focused Batch
        { name: "Cat Typing", description: "Type furiously!", frames: generateHypeDance(), gifUrl: chrome.runtime.getURL("gifs/cat_typing.gif") },
        { name: "Mind Blown", description: "KABOOM!", frames: generateVogueArmsDance(), gifUrl: chrome.runtime.getURL("gifs/mind_blown.gif") },
        { name: "Air Guitar", description: "Shred that guitar!", frames: generateVogueArmsDance(), gifUrl: chrome.runtime.getURL("gifs/air_guitar.gif") },
        { name: "Jazz Hands", description: "Show me your hands!", frames: generateVogueArmsDance(), gifUrl: chrome.runtime.getURL("gifs/jazz_hands.gif") },

        { name: "Shaq Shimmy", description: "Shimmy those shoulders!", frames: generateTikTokSwayDance(), gifUrl: chrome.runtime.getURL("gifs/shaq_shimmy.gif") },


        { name: "Facepalm", description: "Oh no...", frames: generateVogueArmsDance(), gifUrl: chrome.runtime.getURL("gifs/picard_facepalm.gif") },
        { name: "The Force", description: "Use the force!", frames: generateVogueArmsDance(), gifUrl: chrome.runtime.getURL("gifs/baby_yoda_magic.gif") },

        // Final Batch (Reaching 24 total)
        { name: "Salt Bae", description: "Sprinkle that salt!", frames: generateVogueArmsDance(), gifUrl: chrome.runtime.getURL("gifs/salt_bae.gif") },
        { name: "Mic Drop", description: "Boom! Out.", frames: generateVogueArmsDance(), gifUrl: chrome.runtime.getURL("gifs/mic_drop.gif") },
        { name: "Smart Thinking", description: "Use your brain!", frames: generateVogueArmsDance(), gifUrl: chrome.runtime.getURL("gifs/smart_thinking.gif") },
        { name: "Wakanda Forever", description: "Wakanda Forever!", frames: generateVogueArmsDance(), gifUrl: chrome.runtime.getURL("gifs/wakanda_forever.gif") },
        { name: "Deal With It", description: "Too cool for school.", frames: generateVogueArmsDance(), gifUrl: chrome.runtime.getURL("gifs/deal_with_it.gif") },
    ];

    // ============================================================
    // CANVAS DRAWING
    // ============================================================

    var SKELETON_CONNECTIONS = [
        [11, 13], [13, 15], // left arm
        [12, 14], [14, 16], // right arm
        [11, 12],           // shoulders
        [11, 23], [12, 24], // torso sides
        [23, 24],           // hips (static base)
    ];

    function drawPoseOnCanvas(canvas, pose, color, bgColor) {
        var ctx = canvas.getContext("2d");
        var w = canvas.width;
        var h = canvas.height;

        ctx.fillStyle = bgColor || "#111820";
        ctx.fillRect(0, 0, w, h);

        if (!pose) return;

        // Draw gradient background glow
        var glow = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w * 0.45);
        glow.addColorStop(0, "rgba(210, 153, 34, 0.08)");
        glow.addColorStop(1, "transparent");
        ctx.fillStyle = glow;
        ctx.fillRect(0, 0, w, h);

        // Skeleton
        ctx.strokeStyle = color || "#d29922";
        ctx.lineWidth = Math.max(2, w * 0.005);
        ctx.lineCap = "round";

        for (var c = 0; c < SKELETON_CONNECTIONS.length; c++) {
            var a = SKELETON_CONNECTIONS[c][0];
            var b = SKELETON_CONNECTIONS[c][1];
            var pA = pose[a], pB = pose[b];
            if (pA && pB) {
                ctx.beginPath();
                ctx.moveTo(pA.x * w, pA.y * h);
                ctx.lineTo(pB.x * w, pB.y * h);
                ctx.stroke();
            }
        }

        // Keypoints
        var dotRadius = Math.max(3, w * 0.008);
        for (var i = 0; i < pose.length; i++) {
            var p = pose[i];
            if (!p || p.visibility < 0.5) continue;
            ctx.beginPath();
            ctx.arc(p.x * w, p.y * h, dotRadius, 0, Math.PI * 2);
            ctx.fillStyle = (i === 0) ? "#58d68d" : (color || "#d29922");
            ctx.fill();
            ctx.strokeStyle = "#111820";
            ctx.lineWidth = 1.5;
            ctx.stroke();
        }
    }

    // ---- Get current sequence array based on mode ----
    function getCurrentSequences() {
        return challengeMode === 'sillygif' ? SILLYGIF_SEQUENCES : DANCE_SEQUENCES;
    }
    function getCurrentIndex() {
        return challengeMode === 'sillygif' ? currentSillyGifIndex : currentDanceIndex;
    }
    function setCurrentIndex(idx) {
        if (challengeMode === 'sillygif') { currentSillyGifIndex = idx; } else { currentDanceIndex = idx; }
    }

    // ---- Reference animation loop (unified for both modes) ----
    function animateReference() {
        var sequences = getCurrentSequences();
        var idx = getCurrentIndex();
        var dance = sequences[idx];
        if (!dance || !dance.frames.length) return;

        var canvas = referenceCanvas;
        var wrapper = canvas.parentElement;
        canvas.width = wrapper.clientWidth;
        canvas.height = wrapper.clientHeight;

        var elapsed = Date.now() - referenceStartTime;
        var frameIdx = Math.floor(elapsed / SAMPLE_RATE_MS) % dance.frames.length;

        var color = challengeMode === 'sillygif' ? '#e8a317' : '#d29922';
        drawPoseOnCanvas(canvas, dance.frames[frameIdx], color, "#111820");

        // Draw dance name label
        var ctx = canvas.getContext("2d");
        ctx.fillStyle = "rgba(17, 24, 32, 0.7)";
        ctx.fillRect(0, canvas.height - 36, canvas.width, 36);
        ctx.fillStyle = color;
        ctx.font = "bold 14px Inter, sans-serif";
        ctx.textAlign = "center";
        var emoji = challengeMode === 'sillygif' ? '🤪' : '💪';
        ctx.fillText(emoji + " " + dance.name + " — " + dance.description, canvas.width / 2, canvas.height - 12);

        referenceAnimFrame = requestAnimationFrame(animateReference);
    }

    function startReferenceAnimation() {
        stopReferenceAnimation();
        var sequences = getCurrentSequences();
        var idx = getCurrentIndex();
        // Randomize on first use
        if (idx < 0) {
            idx = pickRandomIndex(sequences.length, -1);
            setCurrentIndex(idx);
        }

        var dance = sequences[idx];

        // In Silly GIF mode: show the actual GIF, hide canvas
        if (challengeMode === 'sillygif' && dance && dance.gifUrl) {
            referenceCanvas.style.display = 'none';
            referenceGif.src = dance.gifUrl;
            referenceGif.alt = dance.name;
            referenceGif.classList.add('active');
            referenceGif.classList.remove('hidden-gif');
            referenceGif.style.display = 'block';
            referenceGif.style.width = '100%';
            referenceGif.style.height = '100%';
            referenceGif.style.objectFit = 'contain';
            referenceGif.style.borderRadius = '12px';
            referenceGif.style.background = '#111820';
        } else {
            // Exercise mode: show canvas stick figure, hide GIF
            referenceCanvas.style.display = 'block';
            referenceGif.classList.remove('active');
            referenceGif.style.display = 'none';
        }

        referenceStartTime = Date.now();
        animateReference();
    }

    function stopReferenceAnimation() {
        if (referenceAnimFrame) {
            cancelAnimationFrame(referenceAnimFrame);
            referenceAnimFrame = null;
        }
    }

    // ============================================================
    // MEDIAPIPE POSE LANDMARKER
    // ============================================================

    async function initPoseLandmarker() {
        try {
            controlsHint.textContent = "⏳ Loading AI pose model...";

            // Dynamically load the local MediaPipe bundle
            var bundleURL = getExtensionURL("lib/vision_bundle.mjs");
            var wasmDir = getExtensionURL("lib/wasm/"); // Ensure trailing slash
            var modelPath = getExtensionURL("lib/pose_landmarker_lite.task");

            console.log("Loading MediaPipe from:", bundleURL);
            console.log("WASM dir:", wasmDir);
            console.log("WASM dir:", wasmDir);
            console.log("Model:", modelPath);

            var mp = await import(bundleURL);
            var PoseLandmarker = mp.PoseLandmarker;
            var FilesetResolver = mp.FilesetResolver;

            var vision = await FilesetResolver.forVisionTasks(wasmDir);

            poseLandmarker = await PoseLandmarker.createFromOptions(vision, {
                baseOptions: {
                    modelAssetPath: modelPath,
                    delegate: "CPU",
                },
                runningMode: "VIDEO",
                numPoses: 1,
            });

            console.log("✅ MediaPipe PoseLandmarker initialized successfully");
            return true;
        } catch (err) {
            console.error("❌ MediaPipe init failed:", err);
            console.log("Will use fallback motion detection mode");
            return false;
        }
    }

    // ============================================================
    // WEBCAM
    // ============================================================

    async function initWebcam() {
        try {
            controlsHint.textContent = "📷 Requesting camera access...";
            webcamStream = await navigator.mediaDevices.getUserMedia({
                video: { width: 640, height: 480, facingMode: "user" },
                audio: false,
            });
            webcamVideo.srcObject = webcamStream;
            await webcamVideo.play();
            webcamPlaceholder.classList.add("hidden");

            webcamCanvas.width = webcamVideo.videoWidth || 640;
            webcamCanvas.height = webcamVideo.videoHeight || 480;

            drawWebcamLoop();
            return true;
        } catch (err) {
            console.error("Webcam error:", err);
            controlsHint.textContent = "⚠️ Camera access denied. Please allow camera access and reload.";
            controlsHint.style.color = "#f85149";
            return false;
        }
    }

    function drawWebcamLoop() {
        var ctx = webcamCanvas.getContext("2d");
        var w = webcamCanvas.width;
        var h = webcamCanvas.height;

        ctx.save();
        ctx.scale(-1, 1);
        ctx.drawImage(webcamVideo, -w, 0, w, h);
        ctx.restore();

        if (!isRecording) {
            webcamAnimFrame = requestAnimationFrame(drawWebcamLoop);
        }
    }

    function drawWebcamWithPose(landmarks) {
        var ctx = webcamCanvas.getContext("2d");
        var w = webcamCanvas.width;
        var h = webcamCanvas.height;

        ctx.save();
        ctx.scale(-1, 1);
        ctx.drawImage(webcamVideo, -w, 0, w, h);
        ctx.restore();

        if (!landmarks || !landmarks.length) return;

        // Mirror x for display
        var mirrored = landmarks.map(function (l) {
            return { x: 1 - l.x, y: l.y, z: l.z, visibility: l.visibility };
        });

        ctx.strokeStyle = "#3fb950";
        ctx.lineWidth = 3;
        ctx.lineCap = "round";

        for (var c = 0; c < SKELETON_CONNECTIONS.length; c++) {
            var a = SKELETON_CONNECTIONS[c][0];
            var b = SKELETON_CONNECTIONS[c][1];
            var pA = mirrored[a], pB = mirrored[b];
            if (pA && pB) {
                ctx.beginPath();
                ctx.moveTo(pA.x * w, pA.y * h);
                ctx.lineTo(pB.x * w, pB.y * h);
                ctx.stroke();
            }
        }

        for (var i = 0; i < mirrored.length; i++) {
            if (mirrored[i].visibility < 0.5) continue;
            ctx.beginPath();
            ctx.arc(mirrored[i].x * w, mirrored[i].y * h, 4, 0, Math.PI * 2);
            ctx.fillStyle = "#58d68d";
            ctx.fill();
        }
    }

    // ============================================================
    // POSE SAMPLING
    // ============================================================

    function samplePoseFromWebcam() {
        if (!poseLandmarker || !webcamVideo.videoWidth) return null;

        try {
            var result = poseLandmarker.detectForVideo(webcamVideo, performance.now());
            if (result.landmarks && result.landmarks.length > 0) {
                var landmarks = result.landmarks[0].map(function (l) {
                    return { x: l.x, y: l.y, z: l.z, visibility: l.visibility };
                });
                drawWebcamWithPose(landmarks);
                return landmarks;
            }
        } catch (err) {
            // Silently continue
        }
        return null;
    }

    // ---- Fallback: motion detection when MediaPipe unavailable ----
    var prevFrameData = null;

    function sampleMotionFallback() {
        var ctx = webcamCanvas.getContext("2d");
        var w = webcamCanvas.width;
        var h = webcamCanvas.height;

        // Draw webcam
        ctx.save();
        ctx.scale(-1, 1);
        ctx.drawImage(webcamVideo, -w, 0, w, h);
        ctx.restore();

        // Get pixel data — only sample the upper half of the frame (waist-up)
        try {
            var upperH = Math.floor(h * 0.6); // Top 60% of frame
            var imageData = ctx.getImageData(0, 0, w, upperH);
            var data = imageData.data;

            if (prevFrameData) {
                var totalDiff = 0;
                var sampledPixels = 0;
                // Sample every 10th pixel for performance
                for (var i = 0; i < data.length; i += 40) {
                    totalDiff += Math.abs(data[i] - prevFrameData[i]);
                    totalDiff += Math.abs(data[i + 1] - prevFrameData[i + 1]);
                    totalDiff += Math.abs(data[i + 2] - prevFrameData[i + 2]);
                    sampledPixels++;
                }
                var avgDiff = totalDiff / (sampledPixels * 3);
                // Lower dead zone for better sensitivity to hand/arm movement
                var motionScore = Math.max(0, (avgDiff - 10) / 60);
                motionScore = Math.min(1, motionScore);

                // Show motion indicator bar at bottom of webcam
                ctx.fillStyle = motionScore > 0.2 ? "rgba(63, 185, 80, 0.4)" : "rgba(248, 81, 73, 0.25)";
                ctx.fillRect(0, h - 8, w * motionScore, 8);

                prevFrameData = new Uint8ClampedArray(data);
                return motionScore;
            } else {
                prevFrameData = new Uint8ClampedArray(data);
                return 0;
            }
        } catch (e) {
            return 0;
        }
    }

    // ============================================================
    // POSE COMPARISON
    // ============================================================

    function computeAngle(a, b, c) {
        var ba = { x: a.x - b.x, y: a.y - b.y };
        var bc = { x: c.x - b.x, y: c.y - b.y };
        var dot = ba.x * bc.x + ba.y * bc.y;
        var magBA = Math.sqrt(ba.x * ba.x + ba.y * ba.y);
        var magBC = Math.sqrt(bc.x * bc.x + bc.y * bc.y);
        if (magBA === 0 || magBC === 0) return 0;
        return Math.acos(Math.min(1, Math.max(-1, dot / (magBA * magBC))));
    }

    function extractAngles(pose) {
        return [
            computeAngle(pose[15], pose[13], pose[11]),
            computeAngle(pose[16], pose[14], pose[12]),
            computeAngle(pose[13], pose[11], pose[23]),
            computeAngle(pose[14], pose[12], pose[24]),
            computeAngle(pose[11], pose[23], pose[25]),
            computeAngle(pose[12], pose[24], pose[26]),
            computeAngle(pose[23], pose[25], pose[27]),
            computeAngle(pose[24], pose[26], pose[28]),
        ];
    }

    // Measure how much the user's pose CHANGED between frames — UPPER BODY ONLY
    function poseMovementScore(prevPose, currPose) {
        if (!prevPose || !currPose) return 0;
        var totalDist = 0;
        // Upper body only: shoulders (11,12), elbows (13,14), wrists (15,16)
        var keyPoints = [11, 12, 13, 14, 15, 16];
        for (var i = 0; i < keyPoints.length; i++) {
            var idx = keyPoints[i];
            var p = prevPose[idx];
            var c = currPose[idx];
            if (p && c && p.visibility > 0.5 && c.visibility > 0.5) {
                var dx = c.x - p.x;
                var dy = c.y - p.y;
                totalDist += Math.sqrt(dx * dx + dy * dy);
            }
        }
        return totalDist / keyPoints.length;
    }

    // ---- Per-frame angle similarity between a reference pose and a user pose ----
    function comparePoseAngles(refPose, userPose) {
        if (!refPose || !userPose) return 0;
        var refAngles = extractAngles(refPose);
        var userAngles = extractAngles(userPose);
        var totalSim = 0;
        for (var i = 0; i < refAngles.length; i++) {
            var diff = Math.abs(refAngles[i] - userAngles[i]);
            // Map angle difference to 0–1 similarity (0 diff = 1.0, π diff = 0.0)
            var sim = Math.max(0, 1 - diff / (Math.PI * 0.5));
            totalSim += sim;
        }
        return totalSim / refAngles.length;
    }

    // Score based on how well the user's poses MATCH the pre-stored reference poses
    // Uses angle-based similarity between reference keypoint frames and live user frames
    function comparePoses(referencePoseFrames, userPoseFrames) {
        if (userPoseFrames.length < 2) return 0;

        // Align reference frames to user frames by time index
        var totalFrames = Math.min(referencePoseFrames.length, userPoseFrames.length);
        if (totalFrames === 0) return 0;

        var similarities = [];
        for (var i = 0; i < totalFrames; i++) {
            // Map user frame index to reference frame index (handles different lengths)
            var refIdx = Math.floor(i * referencePoseFrames.length / totalFrames);
            refIdx = Math.min(refIdx, referencePoseFrames.length - 1);
            var sim = comparePoseAngles(referencePoseFrames[refIdx], userPoseFrames[i]);
            similarities.push(sim);
        }

        // Use only the last 60% of frames for scoring (skip early warm-up)
        var startIdx = Math.floor(similarities.length * 0.4);
        var scoredSimilarities = similarities.slice(startIdx);
        if (scoredSimilarities.length === 0) scoredSimilarities = similarities;

        // Average angular similarity
        var totalSim = 0;
        for (var j = 0; j < scoredSimilarities.length; j++) {
            totalSim += scoredSimilarities[j];
        }
        var avgSimilarity = totalSim / scoredSimilarities.length;

        // Also factor in movement activity as a bonus (user should be moving, not standing still)
        var movements = [];
        for (var k = 1; k < userPoseFrames.length; k++) {
            movements.push(poseMovementScore(userPoseFrames[k - 1], userPoseFrames[k]));
        }
        var avgMovement = 0;
        for (var m = 0; m < movements.length; m++) { avgMovement += movements[m]; }
        avgMovement = movements.length > 0 ? avgMovement / movements.length : 0;
        var motionBonus = Math.min(0.1, avgMovement / 0.025 * 0.1);

        // Final score: pose similarity (90% weight) + motion bonus (10% weight)
        return Math.min(0.98, avgSimilarity * 0.9 + motionBonus);
    }

    // ---- Fallback comparison using motion intensity ----
    // Uses only the FINAL portion of frames so the score reflects end-of-recording performance
    function compareMotion(motionScores) {
        if (!motionScores.length) return 0;

        // Skip the first ~1 second as warmup grace period
        var warmupFrames = Math.floor(1000 / SAMPLE_RATE_MS);
        var afterWarmup = motionScores.slice(warmupFrames);
        if (!afterWarmup.length) afterWarmup = motionScores;

        // Use only the last 60% of post-warmup frames for the final score
        var startIdx = Math.floor(afterWarmup.length * 0.4);
        var scoredFrames = afterWarmup.slice(startIdx);
        if (!scoredFrames.length) scoredFrames = afterWarmup;

        // Count frames with significant motion (above noise floor)
        var MOTION_THRESHOLD = 0.20;
        var activeFrames = 0;
        var total = 0;
        for (var i = 0; i < scoredFrames.length; i++) {
            total += scoredFrames[i];
            if (scoredFrames[i] > MOTION_THRESHOLD) {
                activeFrames++;
            }
        }
        var avgMotion = total / scoredFrames.length;
        var activeRatio = activeFrames / scoredFrames.length;

        // Require at least 30% of scored frames to show real motion
        if (activeRatio < 0.3) {
            return avgMotion * activeRatio;
        }

        // Score = average motion weighted by consistency
        return Math.min(0.95, avgMotion * Math.min(1, activeRatio / 0.55));
    }

    // ============================================================
    // CHALLENGE FLOW
    // ============================================================

    function runCountdown() {
        return new Promise(function (resolve) {
            var count = COUNTDOWN_SECONDS;
            countdownOverlay.classList.add("active");
            countdownNumber.textContent = count;

            var interval = setInterval(function () {
                count--;
                if (count > 0) {
                    countdownNumber.textContent = count;
                } else {
                    countdownNumber.textContent = "GO!";
                    setTimeout(function () {
                        countdownOverlay.classList.remove("active");
                        clearInterval(interval);
                        resolve();
                    }, 500);
                }
            }, 1000);
        });
    }

    function runRecording() {
        return new Promise(function (resolve) {
            isRecording = true;
            userPoses = [];
            var motionScores = [];
            var runningScore = 0;
            var sampleCount = 0;

            recordingBadge.classList.remove("hidden");
            timerProgress.classList.remove("hidden");

            // Show live score meter
            var liveMeter = document.getElementById('liveScoreMeter');
            var liveFill = document.getElementById('liveScoreFill');
            var liveValue = document.getElementById('liveScoreValue');
            if (liveMeter) liveMeter.classList.remove('hidden');

            var startTime = Date.now();
            var duration = RECORDING_SECONDS * 1000;

            var sampleInterval = setInterval(function () {
                var elapsed = Date.now() - startTime;
                var progress = Math.min(elapsed / duration, 1);
                timerFill.style.width = (progress * 100) + "%";

                // Color-shift timer: green → amber → red as time runs low
                var remaining = 1 - progress;
                if (remaining < 0.2) {
                    timerFill.style.background = 'linear-gradient(90deg, #b62b24, #f85149)';
                } else if (remaining < 0.4) {
                    timerFill.style.background = 'linear-gradient(90deg, #d29922, #f0b429)';
                } else {
                    timerFill.style.background = '';
                }

                if (poseLandmarker) {
                    var pose = samplePoseFromWebcam();
                    if (pose) {
                        userPoses.push(pose);
                        // Live pose similarity score against reference frames
                        var sequences = getCurrentSequences();
                        var idx = getCurrentIndex();
                        var dance = sequences[idx];
                        if (dance && dance.frames.length > 0) {
                            var elapsed2 = Date.now() - startTime;
                            var refFrameIdx = Math.floor(elapsed2 / SAMPLE_RATE_MS) % dance.frames.length;
                            var sim = comparePoseAngles(dance.frames[refFrameIdx], pose);
                            runningScore += sim;
                            sampleCount++;
                        }
                    }
                } else {
                    var motion = sampleMotionFallback();
                    motionScores.push(motion);
                    runningScore += motion;
                    sampleCount++;
                }

                // Update live score meter
                if (sampleCount > 0 && liveFill && liveValue) {
                    var liveScore = Math.min(100, Math.round((runningScore / sampleCount) * 100));
                    liveFill.style.width = liveScore + '%';
                    liveValue.textContent = liveScore + '%';
                    // Pulse the movement indicator
                    var movePulse = document.getElementById('movePulse');
                    if (movePulse) {
                        var lastSim = (sampleCount > 0) ? (runningScore / sampleCount) : 0;
                        if (lastSim > 0.5) {
                            movePulse.classList.add('active');
                        } else {
                            movePulse.classList.remove('active');
                        }
                    }
                }

                if (elapsed >= duration) {
                    clearInterval(sampleInterval);
                    isRecording = false;
                    recordingBadge.classList.add("hidden");
                    timerProgress.classList.add("hidden");
                    timerFill.style.width = "0%";
                    timerFill.style.background = '';
                    if (liveMeter) liveMeter.classList.add('hidden');
                    drawWebcamLoop();
                    // Pass the live running score so final result matches the live meter exactly
                    var finalLiveScore = sampleCount > 0 ? Math.min(1, runningScore / sampleCount) : 0;
                    resolve({ userPoses: userPoses, motionScores: motionScores, liveScore: finalLiveScore });
                }
            }, SAMPLE_RATE_MS);
        });
    }

    // Animated score count-up
    function animateCountUp(targetPct, callback) {
        var current = 0;
        var step = Math.max(1, Math.floor(targetPct / 30));
        var interval = setInterval(function () {
            current += step;
            if (current >= targetPct) {
                current = targetPct;
                clearInterval(interval);
                if (callback) callback();
            }
            scoreValue.textContent = current + '%';
            scoreFill.style.width = current + '%';
        }, 30);
    }

    function showResult(score, passed) {
        resultOverlay.classList.remove("hidden");
        resultCard.className = "result-card " + (passed ? "pass" : "fail");

        var pct = Math.round(score * 100);

        if (passed) {
            resultIcon.textContent = "🎉";
            resultTitle.textContent = "Nailed It!";
            resultText.textContent = "You matched " + pct + "% of the moves! You've earned your break.";
            resultBtn.textContent = "Back to Browsing →";
        } else {
            resultIcon.textContent = "😬";
            resultTitle.textContent = "Not Quite!";
            resultText.textContent = "You only matched " + pct + "%. You need at least 65%. Try again!";
            resultBtn.textContent = "Try Again";
        }

        // Animated count-up instead of instant display
        scoreValue.textContent = '0%';
        scoreFill.style.width = '0%';
        setTimeout(function () {
            animateCountUp(pct);
        }, 300);

        resultBtn.onclick = function () {
            if (passed) {
                if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
                    // Send score so background can calculate XP
                    chrome.runtime.sendMessage({ type: "CHALLENGE_PASSED", score: score }, function (response) {
                        console.log("CHALLENGE_PASSED response:", response);

                        // Show XP earned briefly before closing
                        if (response && response.xpEarned > 0) {
                            resultIcon.textContent = response.didLevelUp ? "🏆" : "⚡";
                            resultTitle.textContent = response.didLevelUp
                                ? "LEVEL UP! " + response.levelInfo.badge
                                : "+" + response.xpEarned + " Silly Points!";
                            resultText.textContent = response.didLevelUp
                                ? "You reached Level " + response.levelInfo.level + " — " + response.levelInfo.name + "!"
                                : "Total: " + response.totalPoints + " XP • Level " + response.levelInfo.level + " " + response.levelInfo.badge;
                            resultBtn.style.display = "none";
                            scoreFill.style.width = "0%";
                            scoreValue.textContent = "";

                            // Auto-close after showing XP
                            setTimeout(function () {
                                // Window will be closed by background.js, but fallback just in case:
                                window.close();
                            }, 2000);
                        }
                    });
                } else {
                    controlsHint.textContent = "✅ Challenge passed! (In extension mode, this would redirect you back)";
                    controlsHint.style.color = "#3fb950";
                    startBtn.disabled = false;
                }
                // Hide the result overlay for the brief XP display
                resultOverlay.classList.remove("hidden");
            } else {
                resultOverlay.classList.add("hidden");
                scoreFill.style.width = "0%";
                var seqs = getCurrentSequences();
                setCurrentIndex(pickRandomIndex(seqs.length, getCurrentIndex()));
                startReferenceAnimation();
                startBtn.disabled = false;
                controlsHint.textContent = "🔄 New challenge loaded! Press start when ready.";
                controlsHint.style.color = "";
            }
        };
    }

    async function startChallenge() {
        startBtn.disabled = true;
        controlsHint.textContent = "Get in position...";

        await runCountdown();

        controlsHint.textContent = "🔴 Recording! Mirror the moves above!";

        // Sync reference animation with recording
        stopReferenceAnimation();
        referenceStartTime = Date.now();
        animateReference();

        var result = await runRecording();

        controlsHint.textContent = "🧠 Analyzing your moves...";

        // Compute final score: use full pose comparison against reference when available
        var score;
        if (poseLandmarker && result.userPoses.length >= 2) {
            var sequences = getCurrentSequences();
            var idx = getCurrentIndex();
            var dance = sequences[idx];
            score = comparePoses(dance.frames, result.userPoses);
        } else {
            // Fallback: use the live running score (motion-based)
            score = result.liveScore;
        }

        var passed = score >= PASS_THRESHOLD;

        // Dramatic delay
        await new Promise(function (r) { setTimeout(r, 1200); });

        showResult(score, passed);

        if (!passed) {
            startBtn.disabled = false;
        }
    }

    // ============================================================
    // INITIALIZATION
    // ============================================================

    async function init() {
        controlsHint.textContent = "⏳ Loading camera and AI model...";
        startBtn.disabled = true;

        // Set mode-specific UI
        if (challengeMode === 'sillygif') {
            // Randomly select one of the silly GIFs
            currentSillyGifIndex = Math.floor(Math.random() * SILLYGIF_SEQUENCES.length);

            headerBadge.textContent = "🤪 SILLY GIF CHALLENGE";
            headerTitle.textContent = "Copy the Silly Moves";
            headerDesc.textContent = "Watch the silly GIF above, then copy the same moves on camera!";
            refLabel.textContent = "Silly GIF";
        } else {
            headerBadge.textContent = "💪 EXERCISE CHALLENGE";
            headerTitle.textContent = "Mirror the Moves";
            headerDesc.textContent = "Watch the skeleton exercise above, then perform the same moves in front of your camera!";
            refLabel.textContent = "Reference Exercise";
        }

        // Fix back button URL for Chrome extension context
        var backBtn = document.getElementById('backBtn');
        if (backBtn) {
            backBtn.href = getExtensionURL('levels/levels.html');
        }

        // Start reference animation immediately
        startReferenceAnimation();

        // Init webcam
        var webcamOk = await initWebcam();
        if (!webcamOk) return;

        // Try to init MediaPipe
        var mediapipeOk = await initPoseLandmarker();

        if (mediapipeOk) {
            controlsHint.textContent = "✅ Ready! AI pose tracking active. Press Start when you're ready!";
        } else {
            controlsHint.textContent = "✅ Ready! Using motion detection mode. Press Start to begin!";
        }
        controlsHint.style.color = "#3fb950";

        startBtn.disabled = false;
    }

    // ---- Bind events ----
    startBtn.addEventListener("click", startChallenge);

    // Start on page load
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init);
    } else {
        init();
    }

})();
