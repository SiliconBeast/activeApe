// ActiveApe Popup Logic

const $ = (sel) => document.querySelector(sel);

// DOM refs
const timerInput = $("#timerInput");
const sessionBtn = $("#sessionBtn");
const btnIcon = $("#btnIcon");
const btnText = $("#btnText");
const timeDisplay = $("#timeDisplay");
const timeLabel = $("#timeLabel");
const ringProgress = $("#ringProgress");
const statusBar = $("#statusBar");
const statusText = $("#statusText");
const siteInput = $("#siteInput");
const addSiteBtn = $("#addSiteBtn");
const siteList = $("#siteList");
const siteCount = $("#siteCount");
const emptyMsg = $("#emptyMsg");
const timerSelector = $("#timerSelector");
const sitesSection = $(".sites-section");

let lastSessionActive = null; // Track for animation triggers
let lastRenderedSites = null; // Cache to prevent re-render jitter
let lastLocked = null;

// Add SVG gradient definition
const svgEl = document.querySelector(".timer-ring svg");
const defs = document.createElementNS("http://www.w3.org/2000/svg", "defs");
const grad = document.createElementNS("http://www.w3.org/2000/svg", "linearGradient");
grad.setAttribute("id", "progressGradient");
grad.setAttribute("x1", "0%");
grad.setAttribute("y1", "0%");
grad.setAttribute("x2", "100%");
grad.setAttribute("y2", "0%");
const stop1 = document.createElementNS("http://www.w3.org/2000/svg", "stop");
stop1.setAttribute("offset", "0%");
stop1.setAttribute("stop-color", "#238636");
const stop2 = document.createElementNS("http://www.w3.org/2000/svg", "stop");
stop2.setAttribute("offset", "100%");
stop2.setAttribute("stop-color", "#58d68d");
grad.appendChild(stop1);
grad.appendChild(stop2);
defs.appendChild(grad);
svgEl.prepend(defs);

// Circumference of the ring (2πr)
const CIRCUMFERENCE = 2 * Math.PI * 52; // r=52

// ---- Helpers ----
function formatTime(totalSeconds) {
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

function sendMsg(msg) {
    return new Promise((resolve) => {
        try {
            chrome.runtime.sendMessage(msg, (response) => {
                if (chrome.runtime.lastError) {
                    // console.warn("sendMsg error:", chrome.runtime.lastError); // Reduced noise
                    resolve(null);
                } else {
                    resolve(response);
                }
            });
        } catch (e) {
            console.error("sendMsg exception:", e);
            resolve(null);
        }
    });
}

// ---- Render ----
function renderSites(sites, locked) {
    // Skip re-render if nothing changed (prevents hover jitter from polling)
    const key = JSON.stringify(sites);
    if (key === lastRenderedSites && locked === lastLocked) return;
    lastRenderedSites = key;
    lastLocked = locked;

    siteList.innerHTML = "";
    siteCount.textContent = sites.length;
    emptyMsg.classList.toggle("hidden", sites.length > 0);

    sites.forEach((site) => {
        const li = document.createElement("li");
        if (locked) {
            li.innerHTML = `<span class="site-name">${site}</span>`;
        } else {
            li.innerHTML = `
      <span class="site-name">${site}</span>
      <button class="remove-btn" data-site="${site}" title="Remove">✕</button>
    `;
        }
        siteList.appendChild(li);
    });

    // Bind remove buttons (only when not locked)
    if (!locked) {
        document.querySelectorAll(".remove-btn").forEach((btn) => {
            btn.addEventListener("click", async () => {
                const domain = btn.dataset.site;
                const resp = await sendMsg({ type: "REMOVE_SITE", domain });
                // Refresh full state to verify correct locking/button states
                refresh();
            });
        });
    }
}

function updateUI(state) {
    const { isSessionActive, isBlocked, elapsedSeconds, timerLimit, blockedSites } = state;
    const limitSeconds = timerLimit * 60;
    const remaining = Math.max(0, limitSeconds - elapsedSeconds);

    // Timer display
    timeDisplay.textContent = formatTime(remaining);

    // Ring progress
    const progress = elapsedSeconds / limitSeconds;
    const offset = CIRCUMFERENCE * (1 - progress);
    ringProgress.style.strokeDashoffset = offset;

    // Change ring color when blocked
    if (isBlocked) {
        ringProgress.style.stroke = "#f85149";
    } else {
        ringProgress.style.stroke = "";
    }

    // Session button & timer selector animation
    if (isSessionActive) {
        sessionBtn.classList.add("active");
        timerSelector.classList.add("collapsed");
        if (isBlocked) {
            // Blocked: disable stop button, show locked state
            btnIcon.textContent = "🔒";
            btnText.textContent = "Complete Challenge";
            sessionBtn.disabled = true;
            sessionBtn.classList.add("blocked");
        } else {
            btnIcon.textContent = "⏹";
            btnText.textContent = "Stop Session";
            sessionBtn.disabled = false;
            sessionBtn.classList.remove("blocked");
        }
    } else {
        sessionBtn.classList.remove("active", "blocked");
        btnIcon.textContent = "▶";
        btnText.textContent = "Start Focus";
        timerSelector.classList.remove("collapsed");

        // REQ: Disable start button if no sites
        if (!blockedSites || blockedSites.length === 0) {
            sessionBtn.disabled = true;
            sessionBtn.style.opacity = "0.5";
            sessionBtn.title = "Add at least one site to start";
        } else {
            sessionBtn.disabled = false;
            sessionBtn.style.opacity = "1";
            sessionBtn.title = "";
        }
    }

    // Lock / unlock site list AND add inputs
    const addSiteContainer = document.querySelector(".add-site");
    if (isSessionActive) {
        sitesSection.classList.add("locked");
        if (addSiteContainer) addSiteContainer.style.display = "none";
        if (siteInput) siteInput.disabled = true;
        if (addSiteBtn) addSiteBtn.disabled = true;
    } else {
        sitesSection.classList.remove("locked");
        if (addSiteContainer) addSiteContainer.style.display = "flex";
        if (siteInput) siteInput.disabled = false;
        if (addSiteBtn) addSiteBtn.disabled = false;
    }

    // Status bar
    statusBar.className = "status-bar";
    if (isBlocked) {
        statusBar.classList.add("blocked");
        statusText.textContent = "Sites blocked! Complete challenge to continue.";
        timeLabel.textContent = "blocked";
    } else if (isSessionActive) {
        statusBar.classList.add("active");
        statusText.textContent = "Focus session active";
        timeLabel.textContent = "remaining";
    } else {
        statusText.textContent = "Idle";
        timeLabel.textContent = "set a timer";
    }

    // Timer input
    if (document.activeElement !== timerInput) {
        timerInput.value = timerLimit;
    }

    // Sites
    renderSites(blockedSites || [], isSessionActive);

    lastSessionActive = isSessionActive;
}

// ---- Events ----
// Block non-numeric input (no letters, no symbols)
timerInput.addEventListener("keydown", (e) => {
    // Allow: backspace, delete, tab, escape, enter, arrow keys
    const allowed = ["Backspace", "Delete", "Tab", "Escape", "Enter",
        "ArrowLeft", "ArrowRight", "Home", "End"];
    if (allowed.includes(e.key)) return;
    // Allow Ctrl/Cmd + A/C/V/X
    if ((e.ctrlKey || e.metaKey) && ["a", "c", "v", "x"].includes(e.key)) return;
    // Block anything that isn't a digit
    if (!/^[0-9]$/.test(e.key)) {
        e.preventDefault();
    }
});

// Also block paste of non-numeric content
timerInput.addEventListener("paste", (e) => {
    const paste = (e.clipboardData || window.clipboardData).getData("text");
    if (!/^\d+$/.test(paste)) {
        e.preventDefault();
    }
});

// Validate and clamp on blur
timerInput.addEventListener("blur", async () => {
    let val = parseInt(timerInput.value) || 0;
    if (val < 1) val = 1;
    if (val > 90) val = 90;
    timerInput.value = val;
    if (parseInt(timerInput.value) !== val) {
        timerInput.classList.add("invalid");
        setTimeout(() => timerInput.classList.remove("invalid"), 400);
    }
    await sendMsg({ type: "SET_TIMER", timerLimit: val });
});

// Also fire on Enter
timerInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
        timerInput.blur();
    }
});

sessionBtn.addEventListener("click", async () => {
    // Optimistic generic stop attempt if UI thinks we are active
    const currentState = await sendMsg({ type: "GET_STATE" });

    // If we can't get state, but UI shows active, try to stop anyway
    let shouldStop = false;
    let isBlocked = false;

    if (currentState) {
        shouldStop = currentState.isSessionActive;
        isBlocked = currentState.isBlocked;
    } else {
        // Fallback: trust the local UI state if backend is unresponsive
        shouldStop = sessionBtn.classList.contains("active");
    }

    if (shouldStop) {
        // If blocked, don't allow stopping (unless backend is dead, but we can't help that)
        if (isBlocked) return;

        // Optimistic UI Reset: Snap to "Idle" immediately for "OG" feel
        updateUI({
            isSessionActive: false,
            isBlocked: false,
            elapsedSeconds: 0,
            timerLimit: parseInt(timerInput.value) || 25,
            blockedSites: [] // We don't have the list here easily but empty is safe for button state check or we can skip this arg
        });

        const resp = await sendMsg({ type: "STOP_SESSION" });
        if (resp && resp.blocked) {
            // Shouldn't reach here due to UI disable, but just in case
            return;
        }
    } else {
        let limit = parseInt(timerInput.value) || 1;
        if (limit < 1) limit = 1;
        if (limit > 90) limit = 90;
        timerInput.value = limit;
        await sendMsg({ type: "START_SESSION", timerLimit: limit });
    }
    refresh();
});

addSiteBtn.addEventListener("click", addSite);
siteInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") addSite();
});

async function addSite() {
    // REQ: Cannot add sites if session active (Double check state)
    const state = await sendMsg({ type: "GET_STATE" });
    if (state && state.isSessionActive) {
        return; // Silently fail or alert
    }

    const val = siteInput.value.trim();
    if (!val) return;
    // Clean up URL to just domain
    let domain = val;
    try {
        if (val.includes("://")) {
            domain = new URL(val).hostname;
        } else if (val.includes("/")) {
            domain = val.split("/")[0];
        }
    } catch { }
    domain = domain.replace(/^www\./, "").toLowerCase();

    const resp = await sendMsg({ type: "ADD_SITE", domain });
    renderSites(resp.blockedSites || [], false); // Pass false for locked since we know session is inactive
    siteInput.value = "";

    // Refresh UI to update Start button state (enabled/disabled)
    refresh();
}

// ---- XP / Silly Points DOM refs ----
const xpBadge = $("#xpBadge");
const xpLevelName = $("#xpLevelName");
const xpPoints = $("#xpPoints");
const xpFill = $("#xpFill");
const xpDetail = $("#xpDetail");

function renderProfile(profile) {
    if (!profile || !profile.levelInfo) return;
    const li = profile.levelInfo;
    xpBadge.textContent = li.badge;
    xpLevelName.textContent = li.name;
    xpPoints.textContent = li.points + " XP";
    xpFill.style.width = (li.progress * 100) + "%";
    if (li.nextLevel) {
        xpDetail.textContent = `Level ${li.level} · ${li.xpIntoLevel} / ${li.xpForNext} to next level`;
    } else {
        xpDetail.textContent = `Level ${li.level} · MAX LEVEL 🏆`;
    }
}

// ---- Polling ----
let pollTimer = null;

async function refresh() {
    const state = await sendMsg({ type: "GET_STATE" });
    if (state) updateUI(state);
    // Also fetch profile for XP bar
    const profile = await sendMsg({ type: "GET_PROFILE" });
    if (profile) renderProfile(profile);
}

function startPolling() {
    refresh();
    pollTimer = setInterval(refresh, 1000);
}

function stopPolling() {
    if (pollTimer) clearInterval(pollTimer);
}

// Init
document.addEventListener("DOMContentLoaded", () => {
    startPolling();

    // Dark Mode
    const themeToggle = document.getElementById('themeToggle');
    const body = document.body;

    // Load state
    if (localStorage.getItem('darkMode') === 'true') {
        body.classList.add('dark-mode');
        if (themeToggle) themeToggle.textContent = '☀️';
    }

    // Toggle handler
    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            body.classList.toggle('dark-mode');
            const isDark = body.classList.contains('dark-mode');
            localStorage.setItem('darkMode', isDark);

            // Sync via chrome.storage for reliability across all pages
            if (typeof chrome !== 'undefined' && chrome.storage) {
                chrome.storage.local.set({ darkMode: isDark });
            }

            themeToggle.textContent = isDark ? '☀️' : '🌙';
        });
    }

    // Sync from other tabs
    window.addEventListener('storage', (e) => {
        if (e.key === 'darkMode') {
            const isDark = e.newValue === 'true';
            body.classList.toggle('dark-mode', isDark);
            if (themeToggle) themeToggle.textContent = isDark ? '☀️' : '🌙';
        }
    });

    // Open full dashboard (ui.html)
    const headerLink = document.getElementById("headerLink");
    if (headerLink) {
        headerLink.addEventListener("click", () => {
            chrome.tabs.create({ url: chrome.runtime.getURL("ui.html") });
        });
    }
});

// Cleanup when popup closes
window.addEventListener("unload", stopPolling);
